(() => {
  // apps/extension/lib/product-config.mjs
  var V2_VERCEL_APP_ORIGIN = "https://souk-capture-v2.vercel.app";
  var V2_APP_ORIGIN = "https://capture-v2.wearesouk.com";
  var V2_PREVIEW_ORIGIN = "https://souk-capture-frontend-git-v2-de-291bc9-olivier-belauds-projects.vercel.app";
  var DEFAULT_APP_ORIGIN = V2_VERCEL_APP_ORIGIN;
  var DEFAULT_API_ORIGIN = "https://api.wearesouk.com";
  function normalizeAppOrigin(value = DEFAULT_APP_ORIGIN) {
    return normalizeProductOrigin(
      value,
      [V2_VERCEL_APP_ORIGIN, V2_APP_ORIGIN, V2_PREVIEW_ORIGIN],
      "application"
    );
  }
  function normalizeApiOrigin(value = DEFAULT_API_ORIGIN) {
    return normalizeProductOrigin(value, [DEFAULT_API_ORIGIN], "API");
  }
  function isAllowedAppUrl(value) {
    try {
      normalizeAppOrigin(new URL(value).origin);
      return true;
    } catch {
      return false;
    }
  }
  function normalizeProductOrigin(value, productionOrigins, label) {
    const url = new URL(String(value || "").trim());
    const local = url.protocol === "http:" && (url.hostname === "localhost" || url.hostname === "127.0.0.1");
    if (!productionOrigins.includes(url.origin) && !local) {
      throw new Error(`Unauthorized Souk Capture ${label} origin.`);
    }
    return url.origin;
  }

  // apps/extension/lib/upload-journal.mjs
  var DATABASE = "souk-capture-upload-v1";
  var STORE = "uploads";
  var PROGRESS_STORE = "progress";
  var ARTIFACT_STORE = "artifacts";
  var memory = /* @__PURE__ */ new Map();
  var memoryProgress = /* @__PURE__ */ new Map();
  var memoryArtifacts = /* @__PURE__ */ new Map();
  var uploadJournal = Object.freeze({
    async get(id) {
      return withStore("readonly", (store) => request(store.get(id)), () => memory.get(id) || null);
    },
    async put(job) {
      await withStore("readwrite", (store) => request(store.put(job)), () => memory.set(job.id, job));
      return job;
    },
    async stage(job, artifacts) {
      await withStores([STORE, PROGRESS_STORE, ARTIFACT_STORE], "readwrite", async (stores) => {
        await request(stores[STORE].put(job));
        await request(stores[PROGRESS_STORE].delete(job.id));
        for (const kind of ["snapshot", "screenshot", "render-ir"]) {
          await request(stores[ARTIFACT_STORE].delete(`${job.id}:${kind}`));
        }
        for (const artifact of artifacts) {
          await request(stores[ARTIFACT_STORE].put({
            id: `${job.id}:${artifact.kind}`,
            bytes: artifact.bytes
          }));
        }
      }, () => {
        memory.set(job.id, job);
        memoryProgress.delete(job.id);
        for (const kind of ["snapshot", "screenshot", "render-ir"]) {
          memoryArtifacts.delete(`${job.id}:${kind}`);
        }
        for (const artifact of artifacts) {
          memoryArtifacts.set(`${job.id}:${artifact.kind}`, artifact.bytes);
        }
      });
      return job;
    },
    async remove(id) {
      await withStores([STORE, PROGRESS_STORE, ARTIFACT_STORE], "readwrite", async (stores) => {
        await Promise.all([
          request(stores[STORE].delete(id)),
          request(stores[PROGRESS_STORE].delete(id)),
          ...["snapshot", "screenshot", "render-ir"].map(
            (kind) => request(stores[ARTIFACT_STORE].delete(`${id}:${kind}`))
          )
        ]);
      }, () => {
        memory.delete(id);
        memoryProgress.delete(id);
        for (const kind of ["snapshot", "screenshot", "render-ir"]) {
          memoryArtifacts.delete(`${id}:${kind}`);
        }
      });
    },
    async list() {
      return withStore("readonly", (store) => request(store.getAll()), () => [...memory.values()]);
    },
    async getProgress(id) {
      return withStore(
        "readonly",
        (store) => request(store.get(id)),
        () => memoryProgress.get(id) || null,
        PROGRESS_STORE
      );
    },
    async putProgress(id, progress) {
      const value = { id, ...progress };
      await withStore(
        "readwrite",
        (store) => request(store.put(value)),
        () => memoryProgress.set(id, value),
        PROGRESS_STORE
      );
      return value;
    },
    async putArtifact(id, kind, bytes) {
      const key = `${id}:${kind}`;
      await withStore(
        "readwrite",
        (store) => request(store.put({ id: key, bytes })),
        () => memoryArtifacts.set(key, bytes),
        ARTIFACT_STORE
      );
    },
    async getArtifact(id, kind) {
      const key = `${id}:${kind}`;
      const value = await withStore(
        "readonly",
        (store) => request(store.get(key)),
        () => {
          const bytes = memoryArtifacts.get(key);
          return bytes ? { id: key, bytes } : null;
        },
        ARTIFACT_STORE
      );
      return value?.bytes || null;
    }
  });
  async function withStore(mode, operation, fallback, storeName = STORE) {
    return withStores([storeName], mode, (stores) => operation(stores[storeName]), fallback);
  }
  async function withStores(storeNames, mode, operation, fallback) {
    if (!globalThis.indexedDB) {
      if (globalThis.chrome?.runtime) {
        throw new Error("Persistent Chrome storage is unavailable; the upload did not start.");
      }
      return fallback();
    }
    const database = await openDatabase();
    try {
      const transaction = database.transaction(storeNames, mode);
      const stores = Object.fromEntries(storeNames.map((name) => [name, transaction.objectStore(name)]));
      const result = await operation(stores);
      await transactionDone(transaction);
      return result;
    } finally {
      database.close();
    }
  }
  function openDatabase() {
    return new Promise((resolve, reject) => {
      const pending = indexedDB.open(DATABASE, 3);
      pending.onupgradeneeded = () => {
        if (!pending.result.objectStoreNames.contains(STORE)) {
          pending.result.createObjectStore(STORE, { keyPath: "id" });
        }
        if (!pending.result.objectStoreNames.contains(PROGRESS_STORE)) {
          pending.result.createObjectStore(PROGRESS_STORE, { keyPath: "id" });
        }
        if (!pending.result.objectStoreNames.contains(ARTIFACT_STORE)) {
          pending.result.createObjectStore(ARTIFACT_STORE, { keyPath: "id" });
        }
      };
      pending.onsuccess = () => resolve(pending.result);
      pending.onerror = () => reject(pending.error || new Error("The upload journal is unavailable."));
      pending.onblocked = () => reject(new Error("The upload journal is blocked by another extension version."));
    });
  }
  function request(pending) {
    return new Promise((resolve, reject) => {
      pending.onsuccess = () => resolve(pending.result);
      pending.onerror = () => reject(pending.error || new Error("The upload journal could not be written."));
    });
  }
  function transactionDone(transaction) {
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onabort = () => reject(transaction.error || new Error("The upload transaction was cancelled."));
      transaction.onerror = () => reject(transaction.error || new Error("The upload transaction failed."));
    });
  }

  // apps/extension/lib/capture-client.mjs
  var TRACKING = /* @__PURE__ */ new Set(["fbclid", "gclid", "dclid", "msclkid", "mc_cid", "mc_eid", "_ga"]);
  var SENSITIVE_QUERY = /^(?:access_?token|auth|authorization|code|cookie|credential|email|jwt|key|password|passcode|refresh_?token|secret|session|signature|token)$/i;
  function normalizeSceneUrl(input) {
    const url = new URL(String(input || "").trim());
    if (!["http:", "https:"].includes(url.protocol)) throw new Error("This page cannot be captured.");
    if (url.username || url.password) throw new Error("URLs containing credentials are not accepted.");
    url.hash = "";
    for (const key of [...url.searchParams.keys()]) {
      if (key.toLowerCase().startsWith("utm_") || TRACKING.has(key.toLowerCase()) || SENSITIVE_QUERY.test(key)) {
        url.searchParams.delete(key);
      }
    }
    url.searchParams.sort();
    if (url.pathname !== "/") url.pathname = url.pathname.replace(/\/+$/, "") || "/";
    return url.toString();
  }
  function normalizeSceneState(value) {
    return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "default";
  }
  function inferPageType(input) {
    const url = new URL(normalizeSceneUrl(input));
    const segments = url.pathname.split("/").filter(Boolean);
    if (segments[0] && /^[a-z]{2}(?:-[a-z]{2})?$/i.test(segments[0])) segments.shift();
    if (!segments.length) return "home";
    if (segments[0] === "collections" || segments[0] === "search") return "listing";
    if (segments[0] === "products") return "product";
    if (segments[0] === "cart") return "cart";
    if (segments[0] === "checkout") return "checkout";
    if (segments[0] === "wishlist") return "wishlist";
    if (segments[0] === "account" && segments[1] === "login") return "login";
    if (segments[0] === "account" && segments[1] === "orders") return "orders";
    if (segments[0] === "account") return "account";
    return "page";
  }
  var CAPTURE_CHUNK_BYTES = 1e6;
  function chunkBytes(bytes, size = CAPTURE_CHUNK_BYTES) {
    const chunks = [];
    for (let offset = 0; offset < bytes.length; offset += size) chunks.push(bytes.slice(offset, offset + size));
    return chunks;
  }
  function bytesToBase64(bytes) {
    let binary = "";
    const stride = 32768;
    for (let offset = 0; offset < bytes.length; offset += stride) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + stride));
    }
    return btoa(binary);
  }
  function base64ToBytes(value) {
    const binary = atob(String(value || ""));
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
    return bytes;
  }
  async function apiRequest(baseUrl, path, token, init = {}, options = {}) {
    const apiBase = normalizeApiBase(baseUrl);
    const stored = await extensionStorageGet(["accessToken"]).catch(() => ({}));
    const activeToken = options.tokenOverride || stored.accessToken || token;
    const headers = new Headers(init.headers || {});
    headers.set("accept", "application/json");
    if (activeToken) headers.set("authorization", `Bearer ${activeToken}`);
    if (init.body && !headers.has("content-type")) headers.set("content-type", "application/json");
    let response;
    try {
      response = await fetchWithTimeout(new URL(path, apiBase), { ...init, headers }, 2e4);
    } catch (error) {
      if (!options.networkRetryDisabled && !options.networkRetried && (init.method === void 0 || init.method === "GET" || path.includes("/chunks"))) {
        return apiRequest(baseUrl, path, token, init, { ...options, networkRetried: true });
      }
      throw error;
    }
    if (response.status === 401 && !options.authRetried && path !== "/api/customer/refresh") {
      const auth = await extensionStorageGet(["refreshToken"]).catch(() => ({}));
      if (auth.refreshToken) {
        const refreshed = await refreshAccessToken(apiBase, auth.refreshToken);
        return apiRequest(baseUrl, path, token, init, { ...options, authRetried: true, tokenOverride: refreshed });
      }
    }
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(payload.error || payload.message || `Souk error (${response.status})`);
      error.status = response.status;
      error.type = payload.type;
      throw error;
    }
    return payload;
  }
  function normalizeApiBase(value) {
    const url = new URL(normalizeApiOrigin(value));
    url.pathname = "/";
    url.search = "";
    url.hash = "";
    return url.toString();
  }
  var activeUploads = /* @__PURE__ */ new Map();
  var activeCaptureIntents = /* @__PURE__ */ new Map();
  function uploadSnapshot(input) {
    const journal = input.journal || uploadJournal;
    const onProgress = input.onProgress || (() => {
    });
    const token = input.token;
    const intent = uploadIdentity(input.projectId, input.metadata);
    const existing = activeCaptureIntents.get(intent);
    if (existing) return existing;
    const operation = uploadJobId(input.projectId, input.metadata).then(async (id) => {
      const resumed = activeUploads.get(id);
      if (resumed) return resumed;
      const job = await stageUploadJob(input, journal, id);
      return continueUploadJobSingleFlight(job, { token, onProgress, journal });
    });
    activeCaptureIntents.set(intent, operation);
    return operation.finally(() => {
      if (activeCaptureIntents.get(intent) === operation) activeCaptureIntents.delete(intent);
    });
  }
  async function stageUploadJob({
    baseUrl,
    projectId,
    metadata,
    snapshot,
    screenshot,
    screenshotMetadata,
    renderArtifact
  }, journal, id) {
    const bytes = new TextEncoder().encode(snapshot);
    const screenshotBytes = screenshot instanceof Uint8Array ? screenshot : null;
    const renderArtifactBytes = renderArtifact ? renderArtifact.wireBytes || new TextEncoder().encode(JSON.stringify(renderArtifact)) : null;
    if (bytes.length > 4e7) throw new Error("The MHTML capture exceeds the safe 40 MB limit.");
    if (screenshotBytes && screenshotBytes.length > 15e6) {
      throw new Error("The PNG screenshot exceeds the safe 15 MB limit.");
    }
    if (renderArtifactBytes && renderArtifactBytes.length > 25e6) {
      throw new Error("The Render IR exceeds the safe 25 MB limit.");
    }
    const artifactPayloads = [
      { kind: "snapshot", bytes },
      ...screenshotBytes ? [{ kind: "screenshot", bytes: screenshotBytes }] : [],
      ...renderArtifactBytes ? [{ kind: "render-ir", bytes: renderArtifactBytes }] : []
    ];
    const job = {
      id,
      uploadKey: randomHex(16),
      baseUrl,
      projectId,
      metadata: {
        ...metadata,
        url: normalizeSceneUrl(metadata?.url)
      },
      artifacts: artifactPayloads.map(({ kind, bytes: payload }) => ({
        kind,
        byteLength: payload.length
      })),
      screenshotMetadata,
      renderArtifactMetadata: renderArtifactBytes ? {
        schema: renderArtifact.schema,
        version: renderArtifact.version,
        sha256: renderArtifact.integrity?.sha256,
        nodeCount: renderArtifact.domSnapshot?.documents?.reduce(
          (total, document2) => total + (document2.nodes?.nodeType?.length || 0),
          0
        ) || 0,
        controlCount: renderArtifact.controls?.length || 0
      } : null
    };
    await journal.stage(job, artifactPayloads);
    return job;
  }
  async function resumePendingUploads({ token, onProgress = () => {
  }, journal = uploadJournal } = {}) {
    const jobs = await journal.list();
    const results = [];
    for (const job of jobs) {
      try {
        results.push(await continueUploadJobSingleFlight(job, { token, onProgress, journal }));
      } catch (error) {
        results.push({ id: job.id, error: error instanceof Error ? error.message : "Unable to resume the upload." });
      }
    }
    return results;
  }
  function continueUploadJobSingleFlight(job, options) {
    const existing = activeUploads.get(job.id);
    if (existing) return existing;
    const operation = continueUploadJob(job, options);
    activeUploads.set(job.id, operation);
    return operation.finally(() => {
      if (activeUploads.get(job.id) === operation) activeUploads.delete(job.id);
    });
  }
  async function continueUploadJob(job, { token, onProgress, journal }) {
    const { baseUrl, projectId, metadata, artifacts, screenshotMetadata, renderArtifactMetadata } = job;
    let progress = await journal.getProgress(job.id) || {};
    let captureId = progress.captureId;
    let uploadRevision = progress.uploadRevision;
    let duplicate = progress.duplicate;
    if (!captureId || !uploadRevision) {
      const snapshot = artifacts.find((artifact) => artifact.kind === "snapshot");
      const screenshot = artifacts.find((artifact) => artifact.kind === "screenshot");
      const renderArtifact = artifacts.find((artifact) => artifact.kind === "render-ir");
      const started = await apiRequest(baseUrl, `/api/capture-projects/${encodeURIComponent(projectId)}/captures`, token, {
        method: "POST",
        body: JSON.stringify({
          ...metadata,
          uploadKey: job.uploadKey,
          byteLength: snapshot?.byteLength || 0,
          ...screenshot ? {
            screenshotByteLength: screenshot.byteLength,
            screenshot: screenshotMetadata
          } : {},
          ...renderArtifact ? {
            renderArtifactByteLength: renderArtifact.byteLength,
            renderArtifact: renderArtifactMetadata
          } : {}
        })
      });
      if (started.alreadyComplete) {
        await journal.remove(job.id);
        onProgress(100);
        return { ...started, duplicate: true };
      }
      captureId = started.capture?.id;
      uploadRevision = started.uploadRevision;
      duplicate = started.duplicate;
      if (!captureId || !uploadRevision) throw new Error("The backend did not provide an upload revision.");
      progress = await journal.putProgress(job.id, {
        captureId,
        uploadRevision,
        duplicate,
        cursors: {}
      });
    }
    const totalBytes = artifacts.reduce((total, artifact) => total + artifact.byteLength, 0) || 1;
    let completedBytes = 0;
    const counts = {};
    for (const artifact of artifacts) {
      const artifactBytes = await journal.getArtifact(job.id, artifact.kind);
      if (!(artifactBytes instanceof Uint8Array) || artifactBytes.length !== artifact.byteLength) {
        throw new Error(`The Chrome journal no longer contains the ${artifact.kind} artifact.`);
      }
      const startIndex = Number(progress.cursors?.[artifact.kind] || 0);
      counts[artifact.kind] = await uploadArtifactChunks({
        baseUrl,
        token,
        projectId,
        captureId,
        uploadRevision,
        bytes: artifactBytes,
        kind: artifact.kind,
        startIndex,
        onChunk: async (nextIndex) => {
          progress = await journal.putProgress(job.id, {
            captureId,
            uploadRevision,
            duplicate,
            cursors: { ...progress.cursors || {}, [artifact.kind]: nextIndex }
          });
        },
        onProgress: (artifactProgress) => {
          const uploaded = completedBytes + Math.round(artifact.byteLength * artifactProgress);
          onProgress(Math.min(99, Math.round(uploaded / totalBytes * 99)));
        }
      });
      completedBytes += artifact.byteLength;
    }
    const completed = await apiRequest(
      baseUrl,
      `/api/capture-projects/${encodeURIComponent(projectId)}/captures/${encodeURIComponent(captureId)}/complete`,
      token,
      {
        method: "POST",
        body: JSON.stringify({
          chunkCount: counts.snapshot || 0,
          screenshotChunkCount: counts.screenshot || 0,
          renderArtifactChunkCount: counts["render-ir"] || 0,
          uploadRevision
        })
      }
    );
    await journal.remove(job.id);
    onProgress(100);
    return { ...completed, duplicate };
  }
  async function uploadArtifactChunks({
    baseUrl,
    token,
    projectId,
    captureId,
    uploadRevision,
    bytes,
    kind,
    startIndex = 0,
    onChunk = async () => {
    },
    onProgress
  }) {
    const chunkSize = CAPTURE_CHUNK_BYTES;
    const chunkCount = Math.ceil(bytes.length / chunkSize);
    for (let index = startIndex; index < chunkCount; index += 1) {
      const chunk = bytes.subarray(index * chunkSize, Math.min(bytes.length, (index + 1) * chunkSize));
      const uploaded = await retryTransientUpload(() => apiRequest(
        baseUrl,
        `/api/capture-projects/${encodeURIComponent(projectId)}/captures/${encodeURIComponent(captureId)}/chunks`,
        token,
        {
          method: "POST",
          body: JSON.stringify({ index, kind, uploadRevision, data: bytesToBase64(chunk) })
        },
        { networkRetryDisabled: true }
      ));
      if (uploaded?.kind !== kind || uploaded?.index !== index || uploaded?.bytes !== chunk.length) {
        throw new Error("The Souk backend did not confirm the Capture v2 upload protocol.");
      }
      await onChunk(index + 1);
      onProgress((index + 1) / chunkCount);
    }
    return chunkCount;
  }
  async function uploadJobId(projectId, metadata) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(uploadIdentity(projectId, metadata)));
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  function uploadIdentity(projectId, metadata) {
    return [
      projectId,
      normalizeSceneUrl(metadata?.url),
      normalizeSceneState(metadata?.pageType),
      normalizeSceneState(metadata?.stateLabel),
      Math.round(Number(metadata?.viewportWidth) || 1280)
    ].join("\n");
  }
  function randomHex(bytes) {
    const value = crypto.getRandomValues(new Uint8Array(bytes));
    return [...value].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  async function retryTransientUpload(task, {
    attempts = 5,
    sleep = (delay) => new Promise((resolve) => setTimeout(resolve, delay))
  } = {}) {
    let lastError;
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      try {
        return await task(attempt);
      } catch (error) {
        lastError = error;
        const status = Number(error?.status);
        const retryable = !Number.isFinite(status) || status === 408 || status === 425 || status === 429 || status >= 500;
        if (!retryable || attempt === attempts - 1) throw error;
        await sleep(Math.min(4e3, 250 * 2 ** attempt));
      }
    }
    throw lastError;
  }
  async function refreshAccessToken(apiBase, refreshToken) {
    const response = await fetchWithTimeout(new URL("/api/customer/refresh", apiBase), {
      method: "POST",
      headers: { accept: "application/json", "content-type": "application/json" },
      body: JSON.stringify({ refreshToken })
    }, 2e4);
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || !payload.token) {
      await extensionStorageRemove(["accessToken", "refreshToken"]);
      const error = new Error(payload.error || payload.message || "Souk session expired.");
      error.status = response.status;
      throw error;
    }
    await extensionStorageSet({ accessToken: payload.token });
    return payload.token;
  }
  async function fetchWithTimeout(url, init, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, { ...init, signal: controller.signal });
    } catch (error) {
      if (error?.name === "AbortError") throw new Error("The Souk server is not responding. Try again.");
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }
  function extensionStorageGet(keys) {
    return globalThis.chrome?.storage?.local?.get ? globalThis.chrome.storage.local.get(keys) : Promise.resolve({});
  }
  function extensionStorageSet(value) {
    return globalThis.chrome?.storage?.local?.set ? globalThis.chrome.storage.local.set(value) : Promise.resolve();
  }
  function extensionStorageRemove(keys) {
    return globalThis.chrome?.storage?.local?.remove ? globalThis.chrome.storage.local.remove(keys) : Promise.resolve();
  }

  // apps/extension/lib/capture-artifact-v2.mjs
  var CAPTURE_ARTIFACT_SCHEMA = "souk.capture-artifact";
  var CAPTURE_ARTIFACT_VERSION = 2;
  var COMPUTED_STYLE_PROPERTIES = Object.freeze([
    "display",
    "position",
    "inset",
    "top",
    "right",
    "bottom",
    "left",
    "z-index",
    "box-sizing",
    "width",
    "min-width",
    "max-width",
    "height",
    "min-height",
    "max-height",
    "margin-top",
    "margin-right",
    "margin-bottom",
    "margin-left",
    "padding-top",
    "padding-right",
    "padding-bottom",
    "padding-left",
    "overflow-x",
    "overflow-y",
    "visibility",
    "opacity",
    "flex-direction",
    "flex-wrap",
    "flex-grow",
    "flex-shrink",
    "flex-basis",
    "justify-content",
    "align-items",
    "align-content",
    "align-self",
    "order",
    "gap",
    "grid-template-columns",
    "grid-template-rows",
    "grid-column",
    "grid-row",
    "font-family",
    "font-size",
    "font-style",
    "font-weight",
    "font-stretch",
    "line-height",
    "letter-spacing",
    "text-align",
    "text-decoration-line",
    "text-transform",
    "white-space",
    "word-break",
    "color",
    "background-color",
    "background-image",
    "background-position",
    "background-size",
    "background-repeat",
    "border-top-width",
    "border-right-width",
    "border-bottom-width",
    "border-left-width",
    "border-top-style",
    "border-right-style",
    "border-bottom-style",
    "border-left-style",
    "border-top-color",
    "border-right-color",
    "border-bottom-color",
    "border-left-color",
    "border-top-left-radius",
    "border-top-right-radius",
    "border-bottom-right-radius",
    "border-bottom-left-radius",
    "box-shadow",
    "object-fit",
    "object-position",
    "aspect-ratio",
    "transform",
    "transform-origin",
    "transition-property",
    "transition-duration",
    "animation-name",
    "animation-duration",
    "cursor",
    "pointer-events"
  ]);
  var LIMITS = Object.freeze({
    documents: 64,
    nodes: 15e4,
    layoutNodes: 15e4,
    strings: 45e4,
    controls: 5e3,
    serializedBytes: 25e6
  });
  var SENSITIVE_ATTRIBUTE = /(?:^|[-_:])(value|srcdoc|password|passcode|secret|token|csrf|auth|authorization|cookie|session|email|phone|address)(?:$|[-_:])/i;
  var SENSITIVE_QUERY2 = /^(?:access_?token|auth|authorization|code|cookie|credential|email|jwt|key|password|passcode|refresh_?token|secret|session|signature|token)$/i;
  var URL_ATTRIBUTE = /^(?:action|cite|data|formaction|href|manifest|poster|src|srcset|xlink:href)$/i;
  var REDACTED = "[REDACTED]";
  async function createCaptureArtifactV2(input) {
    const pageUrl = sanitizeUrl(input?.page?.url);
    const snapshot = sanitizeSnapshotInPlace(input?.snapshot, pageUrl);
    const controls = normalizeControls(input?.controls);
    const capturedAt = normalizeTimestamp(input?.capturedAt);
    const artifact = {
      schema: CAPTURE_ARTIFACT_SCHEMA,
      version: CAPTURE_ARTIFACT_VERSION,
      capturedAt,
      page: {
        url: pageUrl,
        origin: new URL(pageUrl).origin,
        title: boundedText(input?.page?.title, 300),
        pageType: boundedSlug(input?.page?.pageType, "page"),
        stateLabel: boundedSlug(input?.page?.stateLabel, "default")
      },
      environment: normalizeEnvironment(input?.environment),
      capabilities: normalizeCapabilities(input?.capabilities),
      computedStyleProperties: [...COMPUTED_STYLE_PROPERTIES],
      controls,
      intelligence: sanitizeJsonValue(input?.intelligence, 0, pageUrl),
      domSnapshot: snapshot
    };
    const validation = validateCaptureArtifactV2(artifact);
    if (!validation.ok) throw new Error(`Invalid Capture Artifact v2: ${validation.errors.join("; ")}`);
    const canonical = stableStringify(artifact);
    const byteLength = new TextEncoder().encode(canonical).length;
    if (byteLength > LIMITS.serializedBytes) {
      throw new Error(`Capture Artifact v2 is too large (${byteLength} bytes).`);
    }
    artifact.integrity = {
      algorithm: "sha256",
      sha256: await sha256Hex(canonical),
      byteLength
    };
    const wireBytes = new TextEncoder().encode(JSON.stringify(artifact));
    if (wireBytes.length > LIMITS.serializedBytes) {
      throw new Error(`Capture Artifact v2 is too large (${wireBytes.length} bytes).`);
    }
    Object.defineProperty(artifact, "wireBytes", {
      value: wireBytes,
      enumerable: false,
      configurable: false,
      writable: false
    });
    return artifact;
  }
  function assertSnapshotPrivacy(snapshot) {
    const strings = Array.isArray(snapshot?.strings) ? snapshot.strings : [];
    const stringAt = (index) => Number.isInteger(index) && index >= 0 && index < strings.length ? String(strings[index] || "") : "";
    for (const document2 of snapshot?.documents || []) {
      const nodes = document2?.nodes || {};
      for (const field of ["inputValue", "textValue"]) {
        for (const stringIndex of nodes[field]?.value || []) {
          if (stringAt(stringIndex)) {
            throw new Error("A private field inside a closed component could not be redacted.");
          }
        }
      }
      if ((nodes.optionSelected?.index || []).length) {
        throw new Error("A private selection inside a closed component could not be redacted.");
      }
      for (let nodeIndex = 0; nodeIndex < (nodes.nodeName?.length || 0); nodeIndex += 1) {
        const nodeName = stringAt(nodes.nodeName[nodeIndex]).toLowerCase();
        if (!["input", "textarea", "select", "option"].includes(nodeName)) continue;
        const attributes = nodes.attributes?.[nodeIndex];
        if (!Array.isArray(attributes)) continue;
        for (let offset = 0; offset + 1 < attributes.length; offset += 2) {
          const name = stringAt(attributes[offset]);
          const value = stringAt(attributes[offset + 1]);
          if (SENSITIVE_ATTRIBUTE.test(name) && value) {
            throw new Error("A private attribute inside a closed component could not be redacted.");
          }
        }
      }
    }
  }
  function validateCaptureArtifactV2(artifact) {
    const errors = [];
    if (artifact?.schema !== CAPTURE_ARTIFACT_SCHEMA) errors.push("invalid schema");
    if (artifact?.version !== CAPTURE_ARTIFACT_VERSION) errors.push("unsupported major version");
    if (errors.length) return { ok: false, errors };
    if (!Array.isArray(artifact?.domSnapshot?.strings)) errors.push("missing string table");
    const documents = artifact?.domSnapshot?.documents;
    if (!Array.isArray(documents) || !documents.length) errors.push("missing documents");
    if (documents?.length > LIMITS.documents) errors.push("too many documents");
    if ((artifact?.domSnapshot?.strings?.length || 0) > LIMITS.strings) errors.push("too many strings");
    if ((artifact?.controls?.length || 0) > LIMITS.controls) errors.push("too many controls");
    let nodeCount = 0;
    let layoutCount = 0;
    for (const document2 of documents || []) {
      const nodes = document2?.nodes?.nodeType;
      if (!Array.isArray(nodes)) {
        errors.push("invalid node tree");
        continue;
      }
      nodeCount += nodes.length;
      const attributes = document2?.nodes?.attributes;
      if (!Array.isArray(attributes) || attributes.length !== nodes.length || attributes.some((row) => !Array.isArray(row) || row.length % 2 !== 0)) {
        errors.push("invalid DOM attributes");
      }
      const layoutNodeIndexes = document2?.layout?.nodeIndex;
      if (!Array.isArray(layoutNodeIndexes)) {
        errors.push("invalid layout");
        continue;
      }
      layoutCount += layoutNodeIndexes.length;
      if (layoutNodeIndexes.some((index) => !Number.isInteger(index) || index < 0 || index >= nodes.length)) {
        errors.push("layout nodeIndex out of bounds");
      }
    }
    if (nodeCount > LIMITS.nodes) errors.push("too many nodes");
    if (layoutCount > LIMITS.layoutNodes) errors.push("too many layout nodes");
    return { ok: errors.length === 0, errors: [...new Set(errors)] };
  }
  function stableStringify(value) {
    return JSON.stringify(sortJson(value));
  }
  function sanitizeSnapshotInPlace(snapshot, pageUrl) {
    if (!snapshot || !Array.isArray(snapshot.strings) || !Array.isArray(snapshot.documents)) {
      throw new Error("DOMSnapshot is missing or incomplete.");
    }
    const clone = snapshot;
    clone.strings = clone.strings.map((value) => sanitizeStringTableValue(value, pageUrl));
    const replacements = /* @__PURE__ */ new Map();
    const redactedIndexes = /* @__PURE__ */ new Set();
    for (const document2 of clone.documents) {
      const nodes = document2?.nodes || {};
      redactRareStringData(nodes.inputValue, clone.strings, replacements, redactedIndexes);
      for (const key of ["documentURL", "baseURL"]) {
        const index = document2?.[key];
        if (Number.isInteger(index) && index >= 0 && index < clone.strings.length) {
          clone.strings[index] = sanitizeUrlMaybe(clone.strings[index], pageUrl);
        }
      }
      const baseUrlIndex = document2?.baseURL;
      const documentBaseUrl = Number.isInteger(baseUrlIndex) ? sanitizeUrlMaybe(clone.strings[baseUrlIndex], pageUrl) : pageUrl;
      redactSensitiveAttributes(
        nodes.attributes,
        clone.strings,
        documentBaseUrl,
        replacements,
        redactedIndexes
      );
    }
    for (const index of redactedIndexes) clone.strings[index] = REDACTED;
    return clone;
  }
  function replacementIndex(strings, replacements, originalIndex, value) {
    const key = `${originalIndex}:${value}`;
    if (!replacements.has(key)) replacements.set(key, appendString(strings, value));
    return replacements.get(key);
  }
  function redactRareStringData(data, strings, replacements, redactedIndexes) {
    if (!Array.isArray(data?.value)) return;
    for (let offset = 0; offset < data.value.length; offset += 1) {
      const index = data.value[offset];
      if (!Number.isInteger(index) || index < 0 || index >= strings.length) continue;
      data.value[offset] = replacementIndex(strings, replacements, index, REDACTED);
      redactedIndexes.add(index);
    }
  }
  function redactSensitiveAttributes(attributes, strings, pageUrl, replacements, redactedIndexes) {
    for (const pairs of Array.isArray(attributes) ? attributes : []) {
      if (!Array.isArray(pairs)) continue;
      for (let offset = 0; offset + 1 < pairs.length; offset += 2) {
        const nameIndex = pairs[offset];
        const valueIndex = pairs[offset + 1];
        const name = Number.isInteger(nameIndex) ? strings[nameIndex] : "";
        if (!Number.isInteger(valueIndex) || valueIndex < 0 || valueIndex >= strings.length) continue;
        if (SENSITIVE_ATTRIBUTE.test(name)) {
          pairs[offset + 1] = replacementIndex(strings, replacements, valueIndex, REDACTED);
          redactedIndexes.add(valueIndex);
        } else if (URL_ATTRIBUTE.test(name)) {
          const sanitized = name.toLowerCase() === "srcset" ? sanitizeSrcset(strings[valueIndex], pageUrl) : sanitizeUrlMaybe(strings[valueIndex], pageUrl, true);
          if (sanitized !== strings[valueIndex]) {
            pairs[offset + 1] = replacementIndex(strings, replacements, valueIndex, sanitized);
            redactedIndexes.add(valueIndex);
          }
        }
      }
    }
  }
  function normalizeControls(controls) {
    if (!Array.isArray(controls)) return [];
    return controls.slice(0, LIMITS.controls + 1).map((control) => ({
      role: boundedSlug(control?.role, "control"),
      name: boundedText(control?.name, 200),
      locator: boundedText(control?.locator, 500),
      targetUrl: control?.targetUrl ? sanitizeUrl(control.targetUrl) : "",
      bounds: normalizeBounds(control?.bounds),
      visible: control?.visible === true,
      disabled: control?.disabled === true,
      action: boundedSlug(control?.action, "interact")
    })).sort((left, right) => left.locator.localeCompare(right.locator) || left.role.localeCompare(right.role) || left.name.localeCompare(right.name));
  }
  function normalizeBounds(bounds) {
    const number = (value) => {
      const parsed = Number(value);
      return Number.isFinite(parsed) ? Math.round(parsed * 100) / 100 : 0;
    };
    return {
      x: number(bounds?.x),
      y: number(bounds?.y),
      width: Math.max(0, number(bounds?.width)),
      height: Math.max(0, number(bounds?.height))
    };
  }
  function normalizeEnvironment(environment) {
    const dimension = (value, fallback, maximum = 2e5) => {
      const parsed = Math.round(Number(value));
      return Number.isFinite(parsed) ? Math.min(maximum, Math.max(0, parsed)) : fallback;
    };
    return {
      viewportWidth: dimension(environment?.viewportWidth, 1280, 1e4),
      viewportHeight: dimension(environment?.viewportHeight, 800, 1e4),
      documentWidth: dimension(environment?.documentWidth, 1280),
      documentHeight: dimension(environment?.documentHeight, 800),
      deviceScaleFactor: Math.min(8, Math.max(0.1, Number(environment?.deviceScaleFactor) || 1)),
      locale: boundedText(environment?.locale, 40),
      colorScheme: environment?.colorScheme === "dark" ? "dark" : "light",
      reducedMotion: environment?.reducedMotion === true
    };
  }
  function normalizeCapabilities(capabilities) {
    return Object.fromEntries(Object.entries(capabilities || {}).filter(([key, value]) => /^[a-z][a-zA-Z0-9]{0,80}$/.test(key) && typeof value === "boolean").sort(([left], [right]) => left.localeCompare(right)));
  }
  function sanitizeJsonValue(value, depth, pageUrl) {
    if (depth > 12) return null;
    if (value === null || typeof value === "boolean" || typeof value === "number") return value;
    if (typeof value === "string") return sanitizeStringTableValue(value, pageUrl).slice(0, 1e4);
    if (Array.isArray(value)) {
      return value.slice(0, 1e4).map((item) => sanitizeJsonValue(item, depth + 1, pageUrl));
    }
    if (value && typeof value === "object") {
      return Object.fromEntries(Object.entries(value).filter(([key]) => !SENSITIVE_ATTRIBUTE.test(key)).slice(0, 1e4).map(([key, item]) => [key, sanitizeJsonValue(item, depth + 1, pageUrl)]));
    }
    return null;
  }
  function sanitizeStringTableValue(value, baseUrl) {
    const text = String(value ?? "");
    if (text.length > 2e6) throw new Error("DOMSnapshot string is too large.");
    return sanitizeUrlMaybe(text, baseUrl);
  }
  function sanitizeUrlMaybe(value, baseUrl, allowRelative = false) {
    const text = String(value ?? "");
    if (!allowRelative && !/^(?:https?:)?\/\//i.test(text)) {
      return text;
    }
    try {
      return sanitizeUrl(text, baseUrl);
    } catch {
      return "";
    }
  }
  function sanitizeSrcset(value, baseUrl) {
    return String(value || "").split(",").map((candidate) => {
      const [url, ...descriptor] = candidate.trim().split(/\s+/);
      const sanitized = sanitizeUrlMaybe(url, baseUrl, true);
      return sanitized ? [sanitized, ...descriptor].join(" ") : "";
    }).filter(Boolean).join(", ");
  }
  function appendString(strings, value) {
    strings.push(value);
    return strings.length - 1;
  }
  function sanitizeUrl(value, baseUrl) {
    const url = new URL(String(value || "").trim(), baseUrl);
    if (!["http:", "https:"].includes(url.protocol)) throw new Error("URL non HTTP(S) dans la capture.");
    url.username = "";
    url.password = "";
    url.hash = "";
    for (const key of [...url.searchParams.keys()]) {
      if (SENSITIVE_QUERY2.test(key)) url.searchParams.delete(key);
    }
    url.searchParams.sort();
    return url.toString();
  }
  function boundedText(value, maximum) {
    return String(value || "").trim().replace(/\s+/g, " ").slice(0, maximum);
  }
  function boundedSlug(value, fallback) {
    return String(value || fallback).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || fallback;
  }
  function normalizeTimestamp(value) {
    const date = value ? new Date(value) : /* @__PURE__ */ new Date();
    if (!Number.isFinite(date.getTime())) throw new Error("Invalid capture timestamp.");
    return date.toISOString();
  }
  function sortJson(value) {
    if (Array.isArray(value)) return value.map(sortJson);
    if (!value || typeof value !== "object") return value;
    return Object.fromEntries(Object.keys(value).sort().map((key) => [key, sortJson(value[key])]));
  }
  async function sha256Hex(value) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  // apps/extension/lib/page-intelligence.mjs
  async function prepareAndAnalyzePage(options = {}) {
    const clampInteger = (value, fallback, minimum, maximum) => {
      const parsed = Math.round(Number(value));
      return Number.isFinite(parsed) ? Math.min(maximum, Math.max(minimum, parsed)) : fallback;
    };
    const maxDurationMs = clampInteger(options.maxDurationMs, 8e3, 500, 15e3);
    const maxIterations = clampInteger(options.maxIterations, 18, 2, 30);
    const settleDelayMs = clampInteger(options.settleDelayMs, 180, 20, 500);
    const stableRounds = clampInteger(options.stableRounds, 3, 1, 5);
    const sampleLimit = clampInteger(options.sampleLimit, 2e3, 100, 2e3);
    const startedAt = performance.now();
    const originalScrollY = Math.round(window.scrollY);
    const root = document.documentElement;
    const body = document.body;
    let decodedImages = 0;
    let assetSettleTimeouts = 0;
    const documentHeight = () => Math.max(
      root?.scrollHeight || 0,
      root?.offsetHeight || 0,
      body?.scrollHeight || 0,
      body?.offsetHeight || 0
    );
    const wait = (duration) => new Promise((resolve) => setTimeout(resolve, duration));
    const settleAssets = async (duration = 600, includeOffscreen = false) => {
      const pending = Array.prototype.slice.call(document.images || [], 0, 500).filter((image) => {
        if (includeOffscreen) return !image.complete;
        const rect = image.getBoundingClientRect();
        return !image.complete && rect.bottom >= -window.innerHeight && rect.top <= window.innerHeight * 2;
      }).map(async (image) => {
        try {
          await image.decode();
          decodedImages += 1;
        } catch {
        }
      });
      if (!pending.length) return;
      let timedOut = false;
      await Promise.race([
        Promise.allSettled(pending),
        wait(duration).then(() => {
          timedOut = true;
        })
      ]);
      if (timedOut) assetSettleTimeouts += 1;
    };
    if (document.fonts?.ready) {
      let fontsTimedOut = false;
      await Promise.race([
        document.fonts.ready.catch(() => void 0),
        wait(1200).then(() => {
          fontsTimedOut = true;
        })
      ]);
      if (fontsTimedOut) assetSettleTimeouts += 1;
    }
    const initialDocumentHeight = documentHeight();
    const sampledHeights = [initialDocumentHeight];
    let previousHeight = initialDocumentHeight;
    let growthEvents = 0;
    let consecutiveStableRounds = 0;
    let iterations = 0;
    let stabilized = false;
    let reachedBottom = false;
    let maxScrollY = originalScrollY;
    const coverageIterations = Math.max(1, maxIterations - stableRounds);
    while (iterations < maxIterations && performance.now() - startedAt < maxDurationMs) {
      iterations += 1;
      const viewportHeight = Math.max(1, window.innerHeight);
      const currentHeight = documentHeight();
      const bottomY = Math.max(0, currentHeight - viewportHeight);
      const coverageRoundsLeft = Math.max(1, coverageIterations - iterations + 1);
      const distanceToBottom = Math.max(0, bottomY - window.scrollY);
      const targetY = Math.min(bottomY, Math.round(
        window.scrollY + Math.max(viewportHeight, Math.ceil(distanceToBottom / coverageRoundsLeft))
      ));
      window.scrollTo(0, targetY);
      window.dispatchEvent(new Event("scroll"));
      await wait(settleDelayMs);
      await settleAssets();
      maxScrollY = Math.max(maxScrollY, Math.round(window.scrollY));
      const nextHeight = documentHeight();
      if (nextHeight > previousHeight + 1) growthEvents += 1;
      if (sampledHeights.length < 32 && sampledHeights.at(-1) !== nextHeight) {
        sampledHeights.push(nextHeight);
      }
      const atBottom = window.scrollY + viewportHeight >= nextHeight - 2;
      if (atBottom) reachedBottom = true;
      if (atBottom && nextHeight === previousHeight) {
        consecutiveStableRounds += 1;
      } else {
        consecutiveStableRounds = 0;
      }
      previousHeight = nextHeight;
      if (consecutiveStableRounds >= stableRounds) {
        stabilized = true;
        break;
      }
    }
    const finalDocumentHeight = documentHeight();
    const reachedIterationCap = iterations >= maxIterations;
    const reachedTimeCap = performance.now() - startedAt >= maxDurationMs;
    await settleAssets(3e3, true);
    await wait(250);
    window.scrollTo(0, originalScrollY);
    await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    const increment = (map, value, amount = 1) => {
      if (!value) return;
      map.set(value, (map.get(value) || 0) + amount);
    };
    const ranked = (map, limit) => [...map.entries()].sort((left, right) => right[1] - left[1] || left[0].localeCompare(right[0])).slice(0, limit).map(([value, count]) => ({ value, count }));
    const truncate = (value, maximum = 160) => String(value || "").trim().replace(/\s+/g, " ").slice(0, maximum);
    const isVisibleColor = (value) => {
      const normalized = truncate(value, 80).toLowerCase();
      return normalized && normalized !== "transparent" && normalized !== "rgba(0, 0, 0, 0)" && normalized !== "rgb(0 0 0 / 0)";
    };
    const numericWeight = (value) => {
      if (value === "normal") return 400;
      if (value === "bold") return 700;
      const parsed = Math.round(Number(value));
      return Number.isFinite(parsed) ? Math.min(1e3, Math.max(1, parsed)) : 400;
    };
    const primaryFontFamily = (value) => truncate(String(value || "").split(",")[0], 80).replace(/^["']|["']$/g, "");
    const usageContext = (element) => {
      if (/^H[1-6]$/.test(element.tagName)) return "heading";
      if (element.matches("button, [role='button'], input[type='button'], input[type='submit']")) return "control";
      if (element.closest("nav, [role='navigation']")) return "navigation";
      return "body";
    };
    const safeAssetUrl = (value) => {
      try {
        const url = new URL(String(value || ""), document.baseURI);
        if (!["http:", "https:"].includes(url.protocol)) return "";
        url.username = "";
        url.password = "";
        url.search = "";
        url.hash = "";
        return url.toString().slice(0, 500);
      } catch {
        return "";
      }
    };
    const structuralRegionSelectors = [
      ["header", "header, [role='banner']"],
      ["navigation", "nav, [role='navigation']"],
      ["footer", "footer, [role='contentinfo']"],
      ["product-grid", "[data-product-grid], [class*='product-grid' i], [class*='products-grid' i]"],
      ["product-card", "[data-product-id], [data-product], [class*='product-card' i], article[class*='product' i]"],
      ["cart-drawer", "[data-cart-drawer], [id*='cart-drawer' i], [class*='cart-drawer' i], [role='dialog'][aria-label*='cart' i], [role='dialog'][aria-label*='panier' i]"],
      ["account-navigation", "nav[aria-label*='account' i], nav[aria-label*='compte' i], [data-account-navigation]"],
      ["filters", "[data-filter], [class*='filter' i][role='group']"]
    ];
    const semanticSelectors = [
      ...structuralRegionSelectors,
      ["navbar", "header nav, header [role='navigation'], [role='banner'] nav"],
      ["main", "main, [role='main']"],
      ["section", "section"],
      ["article", "article"],
      ["form", "form"],
      ["button", "button, [role='button'], input[type='button'], input[type='submit']"],
      ["link", "a[href], [role='link']"],
      ["image", "img, picture, svg"],
      ["list", "ul, ol, [role='list']"],
      ["listitem", "li, [role='listitem']"],
      ["dialog", "dialog, [role='dialog']"],
      ["textbox", "textarea, input:not([type]), input[type='text'], input[type='email'], input[type='search'], [role='textbox']"]
    ];
    const allElements = [];
    if (body) {
      allElements.push(body);
      const walker = document.createTreeWalker(body, NodeFilter.SHOW_ELEMENT);
      while (allElements.length < sampleLimit) {
        const element = walker.nextNode();
        if (!element) break;
        allElements.push(element);
      }
    }
    const colors = /* @__PURE__ */ new Map();
    const radii = /* @__PURE__ */ new Map();
    const spacing = /* @__PURE__ */ new Map();
    const fonts = /* @__PURE__ */ new Map();
    const components = /* @__PURE__ */ new Map();
    for (const element of allElements) {
      const style = getComputedStyle(element);
      if (style.display === "none" || style.visibility === "hidden") continue;
      for (const property of ["color", "backgroundColor", "borderTopColor", "borderRightColor", "borderBottomColor", "borderLeftColor"]) {
        const value = truncate(style[property], 80);
        if (isVisibleColor(value)) increment(colors, value);
      }
      for (const property of ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomRightRadius", "borderBottomLeftRadius"]) {
        const value = truncate(style[property], 40);
        if (value && !/^0(?:px|rem|em|%)?(?: 0(?:px|rem|em|%)?)?$/.test(value)) increment(radii, value);
      }
      for (const property of [
        "gap",
        "rowGap",
        "columnGap",
        "marginTop",
        "marginRight",
        "marginBottom",
        "marginLeft",
        "paddingTop",
        "paddingRight",
        "paddingBottom",
        "paddingLeft"
      ]) {
        const value = truncate(style[property], 40);
        if (/^(?:\d+(?:\.\d+)?)(?:px|rem|em|%)$/.test(value) && !/^0(?:px|rem|em|%)$/.test(value)) {
          increment(spacing, value);
        }
      }
      const family = primaryFontFamily(style.fontFamily);
      if (family) {
        const current = fonts.get(family) || {
          family,
          count: 0,
          weights: /* @__PURE__ */ new Map(),
          usage: /* @__PURE__ */ new Map()
        };
        current.count += 1;
        increment(current.weights, numericWeight(style.fontWeight));
        increment(current.usage, usageContext(element));
        fonts.set(family, current);
      }
      for (const [type, selector] of semanticSelectors) {
        if (element.matches(selector)) increment(components, type);
      }
    }
    const visualTokenName = /(?:color|background|surface|border|radius|space|spacing|gap|size|font|line-height|shadow|width|height)/i;
    const safeTokenValue = /^(?:#[\da-f]{3,8}|(?:rgb|rgba|hsl|hsla|oklch|lab|lch)\([^)]{1,100}\)|-?\d+(?:\.\d+)?(?:px|rem|em|%|vh|vw|s|ms|deg)?(?:\s+-?\d+(?:\.\d+)?(?:px|rem|em|%|vh|vw|s|ms|deg)?){0,3}|[a-z][a-z0-9 -]{0,60}(?:,\s*[a-z][a-z0-9 -]{0,60}){0,4})$/i;
    const cssVariableNames = /* @__PURE__ */ new Set();
    const cssVariableDeclarations = /* @__PURE__ */ new Map();
    let inspectedCssRules = 0;
    const collectRuleVariables = (ruleList) => {
      for (let index = 0; index < (ruleList?.length || 0) && inspectedCssRules < 5e3; index += 1) {
        const rule = ruleList[index];
        inspectedCssRules += 1;
        if (rule.style) {
          for (const name of Array.from(rule.style)) {
            if (!name.startsWith("--")) continue;
            cssVariableNames.add(name);
            const value = truncate(rule.style.getPropertyValue(name), 120);
            const key = `${name}\0${value}`;
            if (value && (cssVariableDeclarations.has(key) || cssVariableDeclarations.size < 160)) {
              cssVariableDeclarations.set(key, { name, value });
            }
          }
        }
        if (rule.cssRules) {
          try {
            collectRuleVariables(rule.cssRules);
          } catch {
          }
        }
      }
    };
    for (const sheet of Array.from(document.styleSheets).slice(0, 100)) {
      try {
        collectRuleVariables(sheet.cssRules);
      } catch {
      }
    }
    const rootStyle = getComputedStyle(root);
    for (const name of Array.from(rootStyle)) {
      if (name.startsWith("--")) cssVariableNames.add(name);
    }
    const cssVariables = [
      ...cssVariableDeclarations.values(),
      ...[...cssVariableNames].map((name) => ({
        name,
        value: truncate(rootStyle.getPropertyValue(name), 120)
      }))
    ].filter((token) => /^--[a-z0-9_-]{1,100}$/i.test(token.name) && visualTokenName.test(token.name)).filter((token) => token.value && !/url\s*\(|data:|blob:|["']/i.test(token.value) && safeTokenValue.test(token.value)).filter((token, index, tokens) => tokens.findIndex((candidate) => candidate.name === token.name && candidate.value === token.value) === index).sort((left, right) => left.name.localeCompare(right.name)).slice(0, 80);
    const isRendered = (element) => {
      const style = getComputedStyle(element);
      if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) return false;
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    };
    const productPathPattern = /\/products\/[^/?#]+/i;
    const productLinks = Array.prototype.slice.call(document.querySelectorAll("a[href]"), 0, 1e3).filter((anchor) => {
      if (!isRendered(anchor)) return false;
      try {
        return productPathPattern.test(new URL(anchor.href, document.baseURI).pathname);
      } catch {
        return false;
      }
    });
    const productCards = /* @__PURE__ */ new Set();
    for (const anchor of productLinks) {
      let candidate = anchor.parentElement;
      for (let depth = 0; candidate && depth < 6; depth += 1, candidate = candidate.parentElement) {
        const productPaths = new Set(Array.prototype.slice.call(candidate.querySelectorAll("a[href]"), 0, 10).flatMap((link) => {
          try {
            const pathname = new URL(link.href, document.baseURI).pathname;
            return productPathPattern.test(pathname) ? [pathname.replace(/\/+$/, "").toLowerCase()] : [];
          } catch {
            return [];
          }
        }));
        if (productPaths.size === 1 && candidate.querySelector("img, picture") && /(?:[$€£¥]|USD|EUR|GBP)\s*\d|\d[\d.,\s]*\s*(?:[$€£¥]|USD|EUR|GBP)/i.test(candidate.textContent || "")) {
          productCards.add(candidate);
          break;
        }
      }
    }
    const productGrids = /* @__PURE__ */ new Set();
    for (const card of productCards) {
      const parent = card.parentElement;
      if (!parent || !isRendered(parent)) continue;
      const productChildren = Array.prototype.slice.call(parent.children, 0, 100).filter((child) => Array.prototype.some.call(child.querySelectorAll("a[href]"), (link) => {
        try {
          return productPathPattern.test(new URL(link.href, document.baseURI).pathname);
        } catch {
          return false;
        }
      }));
      if (productChildren.length >= 2) productGrids.add(parent);
    }
    const filterControls = Array.prototype.slice.call(
      document.querySelectorAll("button, [role='button'], select, [data-filter], [class*='filter' i][role='group']"),
      0,
      300
    ).filter((element) => isRendered(element) && /(?:filter|filtern|filtrer|sort|sortieren|trier)/i.test(
      `${element.textContent || ""} ${element.getAttribute("aria-label") || ""}`
    ));
    const addToCartControls = Array.prototype.slice.call(
      document.querySelectorAll("button, [role='button'], input[type='submit']"),
      0,
      300
    ).filter((element) => isRendered(element) && /(?:add\s+to\s+(?:bag|cart)|ajouter\s+au\s+panier|in\s+den\s+warenkorb)/i.test(
      `${element.textContent || ""} ${element.getAttribute("aria-label") || ""} ${element.getAttribute("value") || ""}`
    ));
    const quantityControls = Array.prototype.slice.call(
      document.querySelectorAll("input, [role='spinbutton']"),
      0,
      200
    ).filter((element) => isRendered(element) && /(?:quantity|quantité|menge)/i.test(
      `${element.getAttribute("aria-label") || ""} ${element.getAttribute("name") || ""}`
    ));
    const explicitProductGallery = document.querySelector(
      "[data-product-gallery], [class*='product-gallery' i], [class*='product-media' i]"
    );
    const productGallery = Boolean(
      explicitProductGallery || productPathPattern.test(window.location.pathname) && document.querySelector("main h1, [role='main'] h1") && addToCartControls.length && document.querySelectorAll("main img, [role='main'] img").length >= 2
    );
    const renderedDialogs = Array.prototype.slice.call(
      document.querySelectorAll("[role='dialog'], dialog, [data-slot='sheet-content']"),
      0,
      50
    ).filter(isRendered);
    const cartDrawers = renderedDialogs.filter((element) => /(?:cart|bag|panier|warenkorb)/i.test(
      `${element.textContent || ""} ${element.getAttribute("aria-label") || ""}`
    ));
    const activeInteractionScope = renderedDialogs.find(
      (dialog) => dialog.getAttribute("aria-modal") === "true" || dialog.hasAttribute("data-open") || /\bopen\b/i.test(dialog.getAttribute("data-headlessui-state") || "")
    ) || null;
    if (productCards.size) components.set("product-card", productCards.size);
    if (productGrids.size) components.set("product-grid", productGrids.size);
    if (filterControls.length) components.set("filters", filterControls.length);
    if (productGallery) components.set("product-gallery", 1);
    if (addToCartControls.length) components.set("add-to-cart", addToCartControls.length);
    if (quantityControls.length) components.set("quantity-selector", quantityControls.length);
    if (cartDrawers.length) components.set("cart-drawer", cartDrawers.length);
    const componentManifest = [...components.entries()].map(([type, count]) => ({ type, count }));
    const regions = structuralRegionSelectors.flatMap(([type, selector]) => {
      const count = Array.prototype.slice.call(document.querySelectorAll(selector), 0, 200).filter(isRendered).length;
      return count ? [{ type, count, evidence: "rendered-dom" }] : [];
    });
    if (productGrids.size && !regions.some((region) => region.type === "product-grid")) {
      regions.push({ type: "product-grid", count: productGrids.size, evidence: "product-link-structure" });
    }
    if (productCards.size && !regions.some((region) => region.type === "product-card")) {
      regions.push({ type: "product-card", count: productCards.size, evidence: "product-link-structure" });
    }
    if (filterControls.length && !regions.some((region) => region.type === "filters")) {
      regions.push({ type: "filters", count: filterControls.length, evidence: "labelled-control" });
    }
    if (productGallery && !regions.some((region) => region.type === "product-gallery")) {
      regions.push({ type: "product-gallery", count: 1, evidence: "product-detail-structure" });
    }
    if (cartDrawers.length && !regions.some((region) => region.type === "cart-drawer")) {
      regions.push({ type: "cart-drawer", count: cartDrawers.length, evidence: "open-dialog-content" });
    }
    const internalLinks = /* @__PURE__ */ new Map();
    const externalLinks = /* @__PURE__ */ new Set();
    let pageOrigin = location.origin;
    try {
      if (!pageOrigin || pageOrigin === "null") pageOrigin = new URL(document.baseURI).origin;
    } catch {
      pageOrigin = "";
    }
    for (const anchor of Array.prototype.slice.call(document.querySelectorAll("a[href]"), 0, 1e3)) {
      if (!isRendered(anchor)) continue;
      try {
        const url = new URL(anchor.href, document.baseURI);
        if (!["http:", "https:"].includes(url.protocol)) continue;
        url.hash = "";
        if (!pageOrigin || url.origin !== pageOrigin) {
          externalLinks.add(url.origin);
          continue;
        }
        const path = `${url.pathname || "/"}${url.search}`.slice(0, 500);
        const region = anchor.closest("header, [role='banner']") ? "header" : anchor.closest("footer, [role='contentinfo']") ? "footer" : anchor.closest("nav, [role='navigation']") ? "navigation" : anchor.closest("[data-product-id], [data-product], [class*='product-card' i], article[class*='product' i]") ? "product-card" : "content";
        if (!internalLinks.has(path)) internalLinks.set(path, { path, region, anchor });
      } catch {
      }
    }
    const linkEntries = [...internalLinks.values()].sort((left, right) => left.path.localeCompare(right.path)).slice(0, 200);
    const links = linkEntries.map(({ path, region }) => ({ path, region }));
    const selectorValue = (value) => String(value || "").replace(/\\/g, "\\\\").replace(/"/g, '\\"').slice(0, 160);
    const regionFor = (element) => {
      if (element.closest("header, [role='banner']")) return "header";
      if (element.closest("footer, [role='contentinfo']")) return "footer";
      if (element.closest("[role='dialog'], dialog, [data-slot='sheet-content']")) {
        return cartDrawers.some((drawer) => drawer === element || drawer.contains(element)) ? "cart-drawer" : "dialog";
      }
      if (element.closest("nav, [role='navigation']")) return "navigation";
      if (element.closest("[data-product-id], [data-product], [class*='product-card' i], article[class*='product' i]")) {
        return "product-card";
      }
      return "content";
    };
    const triggerFor = (element, region = regionFor(element)) => {
      const ariaLabel = truncate(element.getAttribute("aria-label"), 120);
      const labelledBy = String(element.getAttribute("aria-labelledby") || "").split(/\s+/).filter(Boolean).map((id) => document.getElementById(id)?.textContent || "").join(" ");
      const controlLabels = element.labels ? Array.from(element.labels).map((label) => label.textContent || "").join(" ") : "";
      const imageAlt = element.matches("img") ? element.getAttribute("alt") || "" : element.querySelector("img[alt]")?.getAttribute("alt") || "";
      const accessibleName = truncate(
        ariaLabel || labelledBy || controlLabels || element.getAttribute("value") || imageAlt || element.getAttribute("title") || element.textContent,
        160
      ).replace(/\s+/g, " ").trim();
      const testId = truncate(element.getAttribute("data-testid"), 120);
      const actionId = truncate(element.getAttribute("data-action"), 120);
      const slot = truncate(element.getAttribute("data-slot"), 80);
      const href = element instanceof HTMLAnchorElement ? (() => {
        try {
          const url = new URL(element.href, document.baseURI);
          return url.origin === pageOrigin ? `${url.pathname || "/"}${url.search}`.slice(0, 500) : "";
        } catch {
          return "";
        }
      })() : "";
      const selector = [
        testId && `[data-testid="${selectorValue(testId)}"]`,
        actionId && `[data-action="${selectorValue(actionId)}"]`,
        ariaLabel && `[aria-label="${selectorValue(ariaLabel)}"]`,
        href && `a[href="${selectorValue(href)}"]`,
        slot && `[data-slot="${selectorValue(slot)}"]`
      ].find(Boolean) || "";
      const rect = element.getBoundingClientRect();
      return {
        tag: element.tagName.toLowerCase(),
        role: truncate(element.getAttribute("role"), 40),
        ariaLabel,
        name: accessibleName,
        selector,
        region,
        disabled: Boolean(element.disabled || element.getAttribute("aria-disabled") === "true"),
        bounds: {
          x: Math.round((rect.left + window.scrollX) * 100) / 100,
          y: Math.round((rect.top + window.scrollY) * 100) / 100,
          width: Math.round(rect.width * 100) / 100,
          height: Math.round(rect.height * 100) / 100
        }
      };
    };
    const stateRegions = cartDrawers.slice(0, 8).map((drawer) => {
      const trigger = triggerFor(drawer, "cart-drawer");
      const ariaLabel = drawer.getAttribute("aria-label");
      return {
        region: "cart-drawer",
        value: drawer.getAttribute("data-state") === "closed" ? "closed" : "open",
        selector: drawer.getAttribute("role") === "dialog" && ariaLabel ? `[role="dialog"][aria-label="${selectorValue(ariaLabel)}"]` : trigger.selector || '[role="dialog"]',
        evidence: "rendered-dom"
      };
    });
    const interactions = linkEntries.filter(({ anchor }) => !activeInteractionScope || activeInteractionScope.contains(anchor)).map(({ path, region, anchor }) => ({
      action: "navigate",
      targetPath: path,
      trigger: triggerFor(anchor, region),
      evidence: "internal-link"
    }));
    const actionableControls = Array.prototype.slice.call(
      document.querySelectorAll("button, [role='button'], input[type='button'], input[type='submit']"),
      0,
      300
    ).filter((control) => isRendered(control) && (!activeInteractionScope || activeInteractionScope.contains(control)));
    for (const control of actionableControls) {
      const signature = `${control.getAttribute("aria-label") || ""} ${control.getAttribute("name") || ""} ${control.getAttribute("value") || ""} ${control.textContent || ""}`;
      const normalized = signature.toLowerCase();
      let action = "";
      let stateRegion = "";
      if (/(?:close|schlie|fermer|cerrar).*(?:cart|bag|panier|warenkorb)|(?:cart|bag|panier|warenkorb).*(?:close|schlie|fermer|cerrar)/i.test(signature)) {
        action = "close-cart";
        stateRegion = "cart-drawer";
      } else if (/(?:open|show|view|öffnen|ouvrir|afficher|anzeigen).*(?:cart|bag|panier|warenkorb)|(?:cart|bag|panier|warenkorb).*(?:open|show|view|öffnen|ouvrir|afficher|anzeigen)/i.test(signature)) {
        action = "open-cart";
        stateRegion = "cart-drawer";
      } else if (control.matches("[data-add-to-cart], [name*='add' i][name*='cart' i]") || /(?:add\s+to\s+(?:bag|cart)|ajouter\s+au\s+panier|in\s+den\s+warenkorb)/i.test(signature)) {
        action = "add-to-cart";
        stateRegion = "cart-drawer";
      } else if (/(?:close|schlie|fermer|cerrar).*(?:menu|navigation)|(?:menu|navigation).*(?:close|schlie|fermer|cerrar)/i.test(signature)) {
        action = "close-menu";
        stateRegion = "navigation";
      } else if (/(?:open|show|öffnen|ouvrir|afficher).*(?:menu|navigation)|(?:menu|navigation).*(?:open|show|öffnen|ouvrir|afficher)/i.test(signature)) {
        action = "open-menu";
        stateRegion = "navigation";
      } else if (/(?:close|schlie|fermer|cerrar).*(?:search|recherche|suche|buscar)|(?:search|recherche|suche|buscar).*(?:close|schlie|fermer|cerrar)/i.test(signature)) {
        action = "close-search";
        stateRegion = "search";
      } else if (/(?:search|recherche|suche|buscar)/i.test(normalized)) {
        action = "open-search";
        stateRegion = "search";
      }
      if (!action) continue;
      interactions.push({
        action,
        trigger: triggerFor(control),
        ...stateRegion ? { stateRegion } : {},
        evidence: "labelled-control"
      });
    }
    interactions.sort(
      (left, right) => (left.action === "navigate" ? 0 : 1) - (right.action === "navigate" ? 0 : 1) || String(left.targetPath || "").localeCompare(String(right.targetPath || "")) || left.action.localeCompare(right.action) || left.trigger.selector.localeCompare(right.trigger.selector)
    );
    const logoCandidates = [];
    for (const image of Array.prototype.slice.call(document.images, 0, 500)) {
      const src = safeAssetUrl(image.currentSrc || image.src);
      if (!src) continue;
      const signature = `${image.id} ${image.className} ${src}`.toLowerCase();
      const reasons = [];
      if (/logo|brand|wordmark|logotype/.test(signature)) reasons.push("name");
      if (image.closest("header, nav, [role='banner'], [role='navigation']")) reasons.push("header");
      const linkedFrom = image.closest("a[href]");
      if (linkedFrom && safeAssetUrl(linkedFrom.href) === `${location.origin}/`) reasons.push("home-link");
      if (!reasons.length) continue;
      const rect = image.getBoundingClientRect();
      logoCandidates.push({
        src,
        width: Math.max(0, Math.round(rect.width || image.naturalWidth || 0)),
        height: Math.max(0, Math.round(rect.height || image.naturalHeight || 0)),
        score: reasons.length,
        reasons: reasons.slice(0, 3)
      });
    }
    for (const link of Array.prototype.slice.call(document.querySelectorAll("link[rel~='icon']"), 0, 8)) {
      const src = safeAssetUrl(link.href);
      if (src) logoCandidates.push({ src, width: 0, height: 0, score: 1, reasons: ["icon"] });
    }
    const logos = [...new Map(
      logoCandidates.sort((left, right) => right.score - left.score || left.src.localeCompare(right.src)).map((candidate) => [candidate.src, candidate])
    ).values()].slice(0, 8);
    const fontManifest = [...fonts.values()].sort((left, right) => right.count - left.count || left.family.localeCompare(right.family)).slice(0, 4).map((font) => ({
      family: font.family,
      count: font.count,
      weights: [...font.weights.entries()].sort((left, right) => right[1] - left[1] || left[0] - right[0]).slice(0, 6).map(([weight]) => weight),
      usage: [...font.usage.entries()].sort((left, right) => right[1] - left[1] || left[0].localeCompare(right[0])).map(([context, count]) => ({ context, count }))
    }));
    const visibleText = truncate(body?.innerText, 2e4);
    const countMatches = (selector) => {
      try {
        return Math.min(1e4, document.querySelectorAll(selector).length);
      } catch {
        return 0;
      }
    };
    const commerceSignals = {
      productCandidates: countMatches(
        "[data-product-id], [data-product], [class*='product-card' i], article[class*='product' i]"
      ),
      priceCandidates: Math.min(
        1e3,
        (visibleText.match(/(?:€|\$|£|CHF)\s?\d|\d(?:[\s.,]\d{2})?\s?(?:€|\$|£|CHF)/g) || []).length
      ),
      addToCartControls: countMatches(
        "[name*='add' i][name*='cart' i], [data-add-to-cart], button[class*='add-to-cart' i]"
      ),
      cartLinks: countMatches("a[href*='/cart' i], a[href*='/panier' i], [data-cart]"),
      searchControls: countMatches(
        "input[type='search'], [role='search'], button[aria-label*='search' i], button[aria-label*='recherche' i]"
      ),
      filterControls: countMatches(
        "[data-filter], button[aria-label*='filter' i], button[aria-label*='filtr' i], select[name*='filter' i]"
      ),
      sortControls: countMatches("select[name*='sort' i], [data-sort], button[aria-label*='sort' i], button[aria-label*='tri' i]"),
      wishlistControls: countMatches(
        "a[href*='wishlist' i], a[href*='favori' i], [data-wishlist], button[aria-label*='wishlist' i], button[aria-label*='favori' i]"
      ),
      accountLinks: countMatches("a[href*='/account' i], a[href*='/compte' i], [data-account]"),
      forms: countMatches("form")
    };
    const sectionCandidates = Array.prototype.slice.call(
      document.querySelectorAll("main > section, main > article, main > div, body > section"),
      0,
      32
    );
    const commerceSections = sectionCandidates.map((section, index) => {
      const sectionText = truncate(section.innerText, 5e3);
      const products = Math.min(1e3, section.querySelectorAll(
        "[data-product-id], [data-product], [class*='product-card' i], article[class*='product' i]"
      ).length);
      const images = Math.min(1e3, section.querySelectorAll("img, picture, video").length);
      const controls = Math.min(1e3, section.querySelectorAll("button, a[href], input, select").length);
      const prices = Math.min(
        1e3,
        (sectionText.match(/(?:€|\$|£|CHF)\s?\d|\d(?:[\s.,]\d{2})?\s?(?:€|\$|£|CHF)/g) || []).length
      );
      const newsletter = Boolean(section.querySelector("input[type='email']"));
      const kind = products >= 3 || prices >= 3 && images >= 3 ? "product-grid" : products > 0 || prices > 0 && images > 0 ? "product-showcase" : newsletter ? "newsletter" : images > 0 && index < 2 ? "hero" : sectionText.length > 200 ? "editorial" : "generic";
      return { index, kind, products, prices, images, controls };
    });
    const safeMotionValue = (value) => {
      const normalized = truncate(value, 160);
      return normalized && !/url\s*\(|data:|blob:|javascript:/i.test(normalized) ? normalized : "";
    };
    const motionProperties = ["opacity", "transform", "filter", "clipPath", "backgroundColor", "color"];
    const pageAnimations = typeof document.getAnimations === "function" ? document.getAnimations().slice(0, 64) : [];
    const motionAnimations = pageAnimations.map((animation) => {
      const effect = animation.effect;
      const target = effect?.target instanceof Element ? effect.target : null;
      const timing = typeof effect?.getComputedTiming === "function" ? effect.getComputedTiming() : {};
      const keyframes = typeof effect?.getKeyframes === "function" ? effect.getKeyframes().slice(0, 8).map((keyframe) => {
        const normalized = {
          offset: Number.isFinite(Number(keyframe.computedOffset)) ? Math.max(0, Math.min(1, Number(keyframe.computedOffset))) : null
        };
        for (const property of motionProperties) {
          const value = safeMotionValue(keyframe[property]);
          if (value) normalized[property] = value;
        }
        return normalized;
      }) : [];
      const constructorName = truncate(animation.constructor?.name, 40);
      return {
        targetIndex: target ? Math.max(0, allElements.indexOf(target)) : 0,
        tag: target ? target.tagName.toLowerCase() : "",
        kind: constructorName === "CSSAnimation" ? "css-animation" : constructorName === "CSSTransition" ? "css-transition" : "web-animation",
        durationMs: Math.max(0, Math.min(6e5, Math.round(Number(timing.duration) || 0))),
        delayMs: Math.max(-6e5, Math.min(6e5, Math.round(Number(timing.delay) || 0))),
        iterations: Number(timing.iterations) === Infinity ? -1 : Math.max(0, Math.min(1e4, Number(timing.iterations) || 0)),
        direction: truncate(timing.direction, 20),
        fill: truncate(timing.fill, 20),
        easing: safeMotionValue(timing.easing),
        keyframes
      };
    });
    const transitionElements = allElements.reduce((count, element) => {
      const style = getComputedStyle(element);
      return count + (style.transitionDuration.split(",").some((value) => Number.parseFloat(value) > 0) ? 1 : 0);
    }, 0);
    return {
      version: 1,
      environment: {
        locale: truncate(document.documentElement.lang || navigator.language, 40),
        deviceScaleFactor: Math.max(0.1, Math.min(8, Number(window.devicePixelRatio) || 1)),
        colorScheme: window.matchMedia?.("(prefers-color-scheme: dark)")?.matches ? "dark" : "light",
        reducedMotion: Boolean(window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches)
      },
      scroll: {
        initialScrollY: originalScrollY,
        restoredScrollY: Math.round(window.scrollY),
        viewportWidth: Math.max(0, Math.round(window.innerWidth)),
        viewportHeight: Math.max(0, Math.round(window.innerHeight)),
        initialDocumentHeight,
        finalDocumentHeight,
        iterations,
        growthEvents,
        stabilized,
        reachedBottom,
        maxScrollY,
        capped: !stabilized && (reachedIterationCap || reachedTimeCap),
        capReason: !stabilized && reachedTimeCap ? "time" : !stabilized && reachedIterationCap ? "iterations" : null,
        durationMs: Math.max(0, Math.round(performance.now() - startedAt)),
        sampledHeights,
        decodedImages,
        assetSettleTimeouts
      },
      design: {
        colors: ranked(colors, 16),
        fonts: fontManifest,
        cssVariables,
        radii: ranked(radii, 12),
        spacing: ranked(spacing, 16),
        components: componentManifest,
        logos,
        sampledElements: allElements.length,
        sampleLimit
      },
      commerce: {
        signals: commerceSignals,
        sections: commerceSections
      },
      structure: {
        route: `${location.pathname || "/"}${location.search}`.slice(0, 500),
        regions,
        links,
        interactions: interactions.slice(0, 200),
        states: stateRegions,
        externalLinkCount: externalLinks.size
      },
      motion: {
        animations: motionAnimations,
        transitionElements,
        truncated: pageAnimations.length >= 64
      }
    };
  }

  // apps/extension/lib/snapshot-fidelity.mjs
  async function applySnapshotFidelity(mode) {
    const stateKey = "__soukCaptureFidelityState";
    const root = globalThis;
    if (mode === "restore") {
      const state2 = root[stateKey];
      const entries2 = Array.isArray(state2) ? state2 : Array.isArray(state2?.entries) ? state2.entries : [];
      const animations2 = Array.isArray(state2?.animations) ? state2.animations : [];
      const scriptedMotion2 = Array.isArray(state2?.scriptedMotion) ? state2.scriptedMotion : [];
      for (const entry of entries2) {
        if (!entry?.element?.style) continue;
        if (entry.value) {
          entry.element.style.setProperty("content-visibility", entry.value, entry.priority || "");
        } else {
          entry.element.style.removeProperty("content-visibility");
        }
      }
      for (const entry of animations2) {
        try {
          entry.animation.currentTime = entry.currentTime;
          if (entry.playState === "running") entry.animation.play();
          else if (entry.playState === "finished") entry.animation.finish();
          else if (entry.playState === "idle") entry.animation.cancel();
          else entry.animation.pause();
        } catch {
        }
      }
      for (const entry of scriptedMotion2) {
        try {
          if (entry.kind === "flickity" && entry.wasPlaying) entry.instance.unpausePlayer?.();
          if (entry.kind === "swiper") {
            if (entry.wasRunning) entry.instance.autoplay?.start?.();
            if (entry.wasPaused) entry.instance.autoplay?.pause?.();
          }
        } catch {
        }
      }
      state2?.fontStyle?.remove?.();
      state2?.captureStyle?.remove?.();
      delete root[stateKey];
      return {
        restored: entries2.length,
        animations: animations2.length,
        scriptedMotion: scriptedMotion2.length,
        fonts: Number(state2?.fonts || 0)
      };
    }
    if (root[stateKey]) {
      const state2 = root[stateKey];
      return {
        applied: Array.isArray(state2) ? state2.length : state2.entries?.length || 0,
        animations: state2.animations?.length || 0,
        scriptedMotion: state2.scriptedMotion?.length || 0,
        fonts: Number(state2.fonts || 0)
      };
    }
    const entries = [];
    const elements = [];
    if (document.body) {
      elements.push(document.body);
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
      while (elements.length < 1e4) {
        const element = walker.nextNode();
        if (!element) break;
        elements.push(element);
      }
    }
    for (const element of elements) {
      if (getComputedStyle(element).contentVisibility !== "auto") continue;
      entries.push({
        element,
        value: element.style.getPropertyValue("content-visibility"),
        priority: element.style.getPropertyPriority("content-visibility")
      });
      element.style.setProperty("content-visibility", "visible", "important");
    }
    const animations = [];
    for (const animation of document.getAnimations?.() || []) {
      try {
        animations.push({
          animation,
          currentTime: animation.currentTime,
          playState: animation.playState
        });
        animation.pause();
        animation.currentTime = 0;
      } catch {
      }
    }
    const scriptedMotion = [];
    for (const element of document.querySelectorAll(".flickity-enabled")) {
      try {
        const instance = root.Flickity?.data?.(element);
        if (!instance) continue;
        const wasPlaying = instance.player?.state === "playing";
        instance.pausePlayer?.();
        scriptedMotion.push({ kind: "flickity", instance, wasPlaying });
      } catch {
      }
    }
    const seenSwipers = /* @__PURE__ */ new Set();
    for (const element of document.querySelectorAll(".swiper, .swiper-container")) {
      try {
        const instance = element.swiper;
        if (!instance || seenSwipers.has(instance)) continue;
        seenSwipers.add(instance);
        const wasRunning = Boolean(instance.autoplay?.running);
        const wasPaused = Boolean(instance.autoplay?.paused);
        instance.autoplay?.stop?.();
        scriptedMotion.push({ kind: "swiper", instance, wasRunning, wasPaused });
      } catch {
      }
    }
    const state = {
      entries,
      animations,
      scriptedMotion,
      fontStyle: null,
      captureStyle: null,
      fonts: 0
    };
    root[stateKey] = state;
    if (document.head) {
      const captureStyle = document.createElement("style");
      captureStyle.dataset.soukSnapshotViewport = "true";
      const nonce = document.querySelector("style[nonce]")?.nonce;
      if (nonce) captureStyle.nonce = nonce;
      captureStyle.textContent = [
        "html{scroll-behavior:auto!important;scrollbar-width:none!important}",
        "html::-webkit-scrollbar{display:none!important}"
      ].join("");
      document.head.append(captureStyle);
      state.captureStyle = captureStyle;
      await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    }
    const fontRules = [];
    const visitedSheets = /* @__PURE__ */ new Set();
    const visitRules = (rules, baseUrl) => {
      for (const rule of Array.from(rules || [])) {
        if (rule?.cssRules) {
          visitRules(rule.cssRules, rule.styleSheet?.href || baseUrl);
        }
        if (rule?.type === 5 || rule?.constructor?.name === "CSSFontFaceRule") {
          fontRules.push({ rule, baseUrl });
        }
      }
    };
    for (const sheet of Array.from(document.styleSheets || [])) {
      if (visitedSheets.has(sheet)) continue;
      visitedSheets.add(sheet);
      try {
        visitRules(sheet.cssRules, sheet.href || document.baseURI);
      } catch {
      }
    }
    const embeddedRules = [];
    let embeddedBytes = 0;
    for (const { rule, baseUrl } of fontRules.slice(0, 32)) {
      const src = rule.style?.getPropertyValue("src") || "";
      const urls = Array.from(src.matchAll(/url\(\s*(?:"([^"]+)"|'([^']+)'|([^)'"\s]+))\s*\)/gi)).map((match) => match[1] || match[2] || match[3]).filter(Boolean);
      let embeddedSource = "";
      for (const candidate of urls) {
        try {
          if (candidate.startsWith("data:")) {
            embeddedSource = `url("${candidate}")`;
            break;
          }
          const response = await fetch(new URL(candidate, baseUrl || document.baseURI).href, {
            credentials: "include",
            cache: "force-cache"
          });
          if (!response.ok) continue;
          const bytes = new Uint8Array(await response.arrayBuffer());
          if (!bytes.length || embeddedBytes + bytes.length > 12e6) continue;
          const signature = String.fromCharCode(...bytes.subarray(0, 4));
          const isFont = signature === "wOFF" || signature === "wOF2" || signature === "OTTO" || bytes[0] === 0 && bytes[1] === 1 && bytes[2] === 0 && bytes[3] === 0;
          if (!isFont) continue;
          let binary = "";
          for (let offset = 0; offset < bytes.length; offset += 32768) {
            binary += String.fromCharCode(...bytes.subarray(offset, offset + 32768));
          }
          const mime = signature === "wOFF" ? "font/woff" : signature === "wOF2" ? "font/woff2" : signature === "OTTO" ? "font/otf" : "font/ttf";
          embeddedSource = `url("data:${mime};base64,${btoa(binary)}")`;
          embeddedBytes += bytes.length;
          break;
        } catch {
        }
      }
      if (!embeddedSource) continue;
      const declarations = [
        ["font-family", rule.style.getPropertyValue("font-family")],
        ["font-style", rule.style.getPropertyValue("font-style")],
        ["font-weight", rule.style.getPropertyValue("font-weight")],
        ["font-stretch", rule.style.getPropertyValue("font-stretch")],
        ["font-feature-settings", rule.style.getPropertyValue("font-feature-settings")],
        ["font-variation-settings", rule.style.getPropertyValue("font-variation-settings")],
        ["unicode-range", rule.style.getPropertyValue("unicode-range")]
      ].filter(([, value]) => value);
      embeddedRules.push(
        `@font-face{${declarations.map(([name, value]) => `${name}:${value}`).join(";")};src:${embeddedSource};font-display:block}`
      );
    }
    if (embeddedRules.length && document.head) {
      const style = document.createElement("style");
      style.dataset.soukSnapshotFonts = "true";
      const nonce = document.querySelector("style[nonce]")?.nonce;
      if (nonce) style.nonce = nonce;
      style.textContent = embeddedRules.join("\n");
      document.head.append(style);
      state.fontStyle = style;
      state.fonts = embeddedRules.length;
      try {
        await document.fonts?.ready;
      } catch {
      }
    }
    return {
      applied: entries.length,
      animations: animations.length,
      scriptedMotion: scriptedMotion.length,
      fonts: state.fonts
    };
  }

  // apps/extension/lib/node-identity.mjs
  function applyCaptureNodeIdentity(mode, prefix = "main") {
    if (mode && typeof mode === "object") {
      prefix = mode.prefix || prefix;
      mode = mode.mode;
    }
    const stateKey = "__soukCaptureNodeIdentity";
    const root = globalThis;
    if (mode === "restore") {
      const entries2 = Array.isArray(root[stateKey]) ? root[stateKey] : [];
      if (!entries2.length) {
        const tagged = [];
        const collect = (container) => {
          for (const element of container.querySelectorAll("[data-souk-capture-node]")) {
            tagged.push(element);
          }
          for (const host of container.querySelectorAll("*")) {
            if (host.shadowRoot) collect(host.shadowRoot);
          }
        };
        collect(document);
        for (const element of tagged) element.removeAttribute("data-souk-capture-node");
        return { restored: tagged.length };
      }
      for (const entry of entries2) {
        if (!entry?.element) continue;
        if (entry.value === null) entry.element.removeAttribute("data-souk-capture-node");
        else entry.element.setAttribute("data-souk-capture-node", entry.value);
      }
      delete root[stateKey];
      return { restored: entries2.length };
    }
    if (Array.isArray(root[stateKey])) return { applied: root[stateKey].length, capped: false };
    const entries = [];
    const seen = /* @__PURE__ */ new Set();
    const visitRoot = (container) => {
      const walker = document.createTreeWalker(container, NodeFilter.SHOW_ELEMENT);
      let element = container.nodeType === Node.ELEMENT_NODE ? container : walker.nextNode();
      while (element && entries.length < 1e5) {
        if (!seen.has(element)) {
          seen.add(element);
          entries.push({
            element,
            value: element.hasAttribute("data-souk-capture-node") ? element.getAttribute("data-souk-capture-node") : null
          });
          element.setAttribute("data-souk-capture-node", `${prefix}-${entries.length - 1}`);
          if (element.shadowRoot) visitRoot(element.shadowRoot);
        }
        element = walker.nextNode();
      }
    };
    visitRoot(document);
    root[stateKey] = entries;
    return { applied: entries.length, capped: entries.length >= 1e5 };
  }

  // apps/extension/lib/snapshot-privacy.mjs
  function applySnapshotPrivacy(mode = "mask") {
    const stateKey = "__soukCapturePrivacyStateV1";
    const root = document.documentElement;
    const restoreAttribute = (element, name, hadAttribute, value) => {
      if (hadAttribute) element.setAttribute(name, value);
      else element.removeAttribute(name);
    };
    const existing = window[stateKey] || root?.[stateKey];
    if (mode === "restore") {
      if (!existing) return { restored: 0, capped: false };
      let restored = 0;
      for (let index = existing.changes.length - 1; index >= 0; index -= 1) {
        try {
          const change = existing.changes[index];
          if (change.kind === "input") {
            change.element.value = change.value;
            change.element.checked = change.checked;
            restoreAttribute(change.element, "value", change.hadValue, change.valueAttribute);
            restoreAttribute(change.element, "checked", change.hadChecked, "");
          } else if (change.kind === "textarea") {
            change.element.value = change.value;
            change.element.textContent = change.text;
          } else if (change.kind === "select") {
            for (const optionState of change.optionStates) {
              optionState.option.selected = optionState.selected;
              restoreAttribute(optionState.option, "selected", optionState.hadSelected, "");
            }
            change.element.selectedIndex = change.selectedIndex;
          } else if (change.kind === "text") {
            change.node.data = change.text;
          } else if (change.kind === "script") {
            change.element.textContent = change.text;
          } else if (change.kind === "attribute") {
            restoreAttribute(change.element, change.name, change.hadAttribute, change.value);
          } else {
            continue;
          }
          restored += 1;
        } catch {
        }
      }
      delete window[stateKey];
      if (root) delete root[stateKey];
      return { restored, capped: false };
    }
    if (existing) return { masked: existing.changes.length, capped: existing.capped };
    const limits = {
      visitedElements: 5e4,
      controls: 2e3,
      options: 5e3,
      editableTextNodes: 5e3,
      scripts: 500,
      privateAttributes: 5e3
    };
    const state = { changes: [], capped: false };
    window[stateKey] = state;
    if (root) root[stateKey] = state;
    let visitedElements = 0;
    let controls = 0;
    let options = 0;
    let maskedTextNodes = 0;
    let scripts = 0;
    let privateAttributes = 0;
    const privateRegionPattern = /(?:customer[-_ ]?name|order[-_ ]?(?:number|id)|billing|shipping|payment|address|phone|telephone|e-?mail|profile[-_ ]?(?:name|details)|card[-_ ]?(?:number|holder)|data-souk-private)/i;
    const privateAttributePattern = /(?:^|[-_:])(?:auth|authorization|cookie|credential|csrf|email|jwt|key|password|passcode|phone|secret|session|signature|token)(?:$|[-_:])/i;
    const structuredSecretPattern = /["']?(?:auth|authorization|cookie|credential|csrf|email|jwt|password|passcode|phone|secret|session|signature|token)["']?\s*[:=]/i;
    const maskedPrivateRoots = /* @__PURE__ */ new WeakSet();
    if (!root) return { masked: 0, capped: false };
    const roots = [root];
    while (roots.length && visitedElements < limits.visitedElements) {
      const traversalRoot = roots.pop();
      const walker = document.createTreeWalker(traversalRoot, NodeFilter.SHOW_ELEMENT);
      let element = traversalRoot;
      while (element && visitedElements < limits.visitedElements) {
        visitedElements += 1;
        try {
          if (element.shadowRoot) roots.push(element.shadowRoot);
          for (const attribute of [...element.attributes || []]) {
            if (privateAttributePattern.test(attribute.name) || structuredSecretPattern.test(attribute.value)) {
              if (privateAttributes >= limits.privateAttributes) {
                state.capped = true;
                break;
              }
              privateAttributes += 1;
              state.changes.push({
                kind: "attribute",
                element,
                name: attribute.name,
                hadAttribute: true,
                value: attribute.value
              });
              element.setAttribute(attribute.name, attribute.value.replace(/\S/g, "\u2022"));
            }
          }
          const privateDescriptor = [
            element.id,
            element.className,
            element.getAttribute?.("name"),
            element.getAttribute?.("aria-label"),
            element.getAttribute?.("autocomplete"),
            element.hasAttribute?.("data-souk-private") ? "data-souk-private" : ""
          ].join(" ");
          const privateAncestor = element.parentElement?.closest?.(
            "[data-souk-private],[data-private],[data-sensitive]"
          );
          if (element instanceof HTMLElement && !maskedPrivateRoots.has(element) && !privateAncestor && (element.hasAttribute("data-souk-private") || element.hasAttribute("data-private") || element.hasAttribute("data-sensitive") || privateRegionPattern.test(privateDescriptor))) {
            maskedPrivateRoots.add(element);
            const textWalker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
            let textNode = textWalker.nextNode();
            while (textNode) {
              if (maskedTextNodes >= limits.editableTextNodes) {
                state.capped = true;
                break;
              }
              if (textNode.data.trim()) {
                maskedTextNodes += 1;
                const text = textNode.data;
                state.changes.push({ kind: "text", node: textNode, text });
                textNode.data = text.replace(/\S/g, "\u2022");
              }
              textNode = textWalker.nextNode();
            }
          }
          if ((element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element instanceof HTMLSelectElement) && controls >= limits.controls) {
            state.capped = true;
          }
          if (element instanceof HTMLInputElement && controls < limits.controls) {
            controls += 1;
            const value = element.value;
            const hadValue = element.hasAttribute("value");
            const valueAttribute = element.getAttribute("value") || "";
            const checked = element.checked;
            const hadChecked = element.hasAttribute("checked");
            state.changes.push({
              kind: "input",
              element,
              value,
              hadValue,
              valueAttribute,
              checked,
              hadChecked
            });
            element.value = "";
            element.checked = false;
            element.setAttribute("value", "");
            element.removeAttribute("checked");
          } else if (element instanceof HTMLTextAreaElement && controls < limits.controls) {
            controls += 1;
            const value = element.value;
            const text = element.textContent || "";
            state.changes.push({ kind: "textarea", element, value, text });
            element.value = "";
            element.textContent = "";
          } else if (element instanceof HTMLSelectElement && controls < limits.controls) {
            controls += 1;
            const selectedIndex = element.selectedIndex;
            const optionStates = [];
            for (const option of element.options) {
              if (options >= limits.options) {
                state.capped = true;
                break;
              }
              options += 1;
              optionStates.push({
                option,
                selected: option.selected,
                hadSelected: option.hasAttribute("selected")
              });
              if (option.selected) {
                const textWalker = document.createTreeWalker(option, NodeFilter.SHOW_TEXT);
                let textNode = textWalker.nextNode();
                while (textNode) {
                  if (maskedTextNodes >= limits.editableTextNodes) {
                    state.capped = true;
                    break;
                  }
                  maskedTextNodes += 1;
                  const text = textNode.data;
                  state.changes.push({ kind: "text", node: textNode, text });
                  textNode.data = text.replace(/\S/g, "\u2022");
                  textNode = textWalker.nextNode();
                }
              }
              option.selected = false;
              option.removeAttribute("selected");
            }
            state.changes.push({ kind: "select", element, selectedIndex, optionStates });
            element.selectedIndex = -1;
          } else if (element instanceof HTMLScriptElement && !element.src) {
            if (scripts >= limits.scripts) {
              state.capped = true;
            } else {
              scripts += 1;
              const text = element.textContent || "";
              state.changes.push({ kind: "script", element, text });
              element.textContent = "/* Souk capture: inline script redacted */";
            }
          }
          if (element instanceof HTMLElement && element.isContentEditable && !element.parentElement?.isContentEditable) {
            const textWalker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
            let textNode = textWalker.nextNode();
            while (textNode) {
              if (maskedTextNodes >= limits.editableTextNodes) {
                state.capped = true;
                break;
              }
              maskedTextNodes += 1;
              const text = textNode.data;
              state.changes.push({ kind: "text", node: textNode, text });
              textNode.data = text.replace(/\S/g, "\u2022");
              textNode = textWalker.nextNode();
            }
          }
        } catch {
          state.capped = true;
        }
        element = walker.nextNode();
      }
    }
    if (roots.length) state.capped = true;
    return {
      masked: state.changes.length,
      capped: state.capped,
      visitedElements
    };
  }

  // apps/extension/lib/capture-viewport.mjs
  var DEFAULT_VIEWPORT = {
    width: 1280,
    height: 800
  };
  function resolveCaptureViewport({
    page,
    tab,
    designManifest,
    screenshotMetadata
  }) {
    const scroll = designManifest?.scroll || {};
    return {
      width: boundedDimension(
        scroll.viewportWidth,
        page?.width,
        screenshotMetadata?.width,
        tab?.width,
        DEFAULT_VIEWPORT.width
      ),
      height: boundedDimension(
        scroll.viewportHeight,
        page?.height,
        tab?.height,
        DEFAULT_VIEWPORT.height
      )
    };
  }
  function boundedDimension(...candidates) {
    for (const candidate of candidates) {
      const value = Math.round(Number(candidate));
      if (Number.isFinite(value) && value > 0 && value <= 2e4) return value;
    }
    throw new Error("Invalid capture viewport dimension.");
  }

  // apps/extension/lib/mhtml-supplement.mjs
  var MAX_RESOURCE_BYTES = 12 * 1024 * 1024;
  var MAX_TOTAL_BYTES = 48 * 1024 * 1024;
  var MAX_ARCHIVE_BYTES = 72e6;
  var MAX_RESOURCE_COUNT = 500;
  function currentSourceUrls(snapshot, renderedUrls) {
    const strings = Array.isArray(snapshot?.strings) ? snapshot.strings : [];
    const rendered = renderedUrls ? new Set(renderedUrls) : null;
    const urls = /* @__PURE__ */ new Set();
    for (const document2 of snapshot?.documents || []) {
      const nodes = document2?.nodes || {};
      const column = nodes.currentSourceURL;
      for (const value of column?.value || []) {
        const url = String(strings[Number(value)] || "");
        if (/^https?:\/\//i.test(url) && (!rendered || rendered.has(url))) urls.add(url);
      }
      for (let index = 0; index < (nodes.nodeName || []).length; index += 1) {
        if (String(strings[Number(nodes.nodeName[index])] || "").toLowerCase() !== "link") continue;
        const attributes = nodes.attributes?.[index] || [];
        const values = Object.fromEntries(
          Array.from({ length: Math.floor(attributes.length / 2) }, (_, pairIndex) => [
            String(strings[Number(attributes[pairIndex * 2])] || "").toLowerCase(),
            String(strings[Number(attributes[pairIndex * 2 + 1])] || "")
          ])
        );
        const icon = String(values.rel || "").toLowerCase().split(/\s+/).some((token) => token === "icon" || token.endsWith("-icon"));
        if (icon && /^https?:\/\//i.test(values.href || "")) urls.add(values.href);
      }
    }
    return [...urls].sort();
  }
  function missingMhtmlLocations(mhtml, urls) {
    const existing = new Set(
      [...String(mhtml).matchAll(/^Content-Location:\s*(.+?)\r?$/gmi)].map((match) => match[1].trim())
    );
    return urls.filter((url) => !existing.has(url));
  }
  function assertMhtmlResourceCount(urls) {
    if (!Array.isArray(urls) || urls.length > MAX_RESOURCE_COUNT) {
      throw new Error("The page contains too many responsive assets for a reliable capture.");
    }
    return urls;
  }
  function appendMhtmlResources(mhtml, resources) {
    const source = String(mhtml);
    const boundaryMatch = source.match(/boundary\s*=\s*(?:"([^"]+)"|([^;\r\n]+))/i);
    const boundary = boundaryMatch?.[1] || boundaryMatch?.[2]?.trim();
    if (!boundary) throw new Error("The MHTML boundary could not be found.");
    const closing = `--${boundary}--`;
    const closingIndex = source.lastIndexOf(closing);
    if (closingIndex < 0) throw new Error("The end of the MHTML snapshot could not be found.");
    let totalBytes = 0;
    let archiveBytes = new TextEncoder().encode(source).byteLength;
    const parts = [];
    for (const resource of resources) {
      const bytes = resource?.bytes;
      if (!(bytes instanceof Uint8Array) || !/^https?:\/\//i.test(resource.url || "")) continue;
      if (bytes.byteLength > MAX_RESOURCE_BYTES || totalBytes + bytes.byteLength > MAX_TOTAL_BYTES) {
        throw new Error("The page's exact assets exceed the safe capture limit.");
      }
      totalBytes += bytes.byteLength;
      const base64 = bytesToBase642(bytes).replace(/.{1,76}/g, "$&\r\n").trimEnd();
      const part = [
        `--${boundary}`,
        `Content-Type: ${safeMimeType(resource.mimeType)}`,
        "Content-Transfer-Encoding: base64",
        `Content-Location: ${resource.url}`,
        "",
        base64,
        ""
      ].join("\r\n");
      archiveBytes += new TextEncoder().encode(part).byteLength;
      if (archiveBytes > MAX_ARCHIVE_BYTES) {
        throw new Error("The complete MHTML snapshot exceeds the safe upload limit.");
      }
      parts.push(part);
    }
    if (!parts.length) return source;
    return `${source.slice(0, closingIndex)}${parts.join("")}${source.slice(closingIndex)}`;
  }
  function safeMimeType(value) {
    const mime = String(value || "").split(";")[0].trim().toLowerCase();
    return /^(?:image\/(?:avif|gif|jpeg|png|svg\+xml|webp|x-icon)|font\/(?:otf|ttf|woff2?)|text\/css|video\/(?:mp4|webm))$/.test(mime) ? mime : "application/octet-stream";
  }
  function bytesToBase642(bytes) {
    let binary = "";
    for (let offset = 0; offset < bytes.length; offset += 32768) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + 32768));
    }
    return btoa(binary);
  }

  // apps/extension/lib/screenshot-stitch.mjs
  var MAX_SCREENSHOT_HEIGHT = 2e4;
  var MAX_SCREENSHOT_PIXELS = 32e6;
  function screenshotTilePlan({
    viewportHeight,
    documentHeight,
    viewportWidth
  }) {
    const width = bounded(viewportWidth);
    const visibleHeight = bounded(viewportHeight);
    const sourceHeight = bounded(documentHeight, 1e6);
    const height = Math.min(
      MAX_SCREENSHOT_HEIGHT,
      Math.floor(MAX_SCREENSHOT_PIXELS / width),
      sourceHeight
    );
    const maxScrollY = Math.max(0, sourceHeight - visibleHeight);
    const scrollPositions = [];
    for (let destinationY = 0; destinationY < height; destinationY += visibleHeight) {
      scrollPositions.push(Math.min(destinationY, maxScrollY));
    }
    return {
      width,
      height,
      fullPage: height >= sourceHeight,
      truncated: height < sourceHeight,
      tiles: [...new Set(scrollPositions)].map((scrollY, index, positions) => {
        const destinationY = index === 0 ? 0 : positions[index - 1] + visibleHeight;
        const endY = Math.min(height, scrollY + visibleHeight);
        return {
          scrollY,
          sourceY: Math.max(0, destinationY - scrollY),
          destinationY,
          height: Math.max(0, endY - destinationY)
        };
      }).filter((tile) => tile.height > 0)
    };
  }
  async function stitchScreenshotTiles(plan, captures) {
    if (!captures.length || captures.length !== plan.tiles.length) {
      throw new Error("The screenshot tile count is inconsistent.");
    }
    const decoded = await Promise.all(captures.map(async (data) => {
      const response = await fetch(`data:image/png;base64,${data}`);
      return createImageBitmap(await response.blob());
    }));
    const width = decoded[0].width;
    if (decoded.some((image) => image.width !== width)) {
      decoded.forEach((image) => image.close());
      throw new Error("The screenshot tiles do not all have the same width.");
    }
    try {
      for (let index = 0; index < decoded.length; index += 1) {
        const image = decoded[index];
        const tile = plan.tiles[index];
        if (image.height < tile.sourceY + tile.height) {
          throw new Error("A screenshot tile does not cover the expected area.");
        }
      }
      const canvas = new OffscreenCanvas(width, plan.height);
      const context = canvas.getContext("2d", { alpha: false });
      if (!context) throw new Error("Chrome ne fournit aucun canvas de capture.");
      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, width, plan.height);
      for (let index = 0; index < decoded.length; index += 1) {
        const image = decoded[index];
        const tile = plan.tiles[index];
        context.drawImage(
          image,
          0,
          tile.sourceY,
          image.width,
          tile.height,
          0,
          tile.destinationY,
          width,
          tile.height
        );
      }
      const blob = await canvas.convertToBlob({ type: "image/png" });
      return {
        data: await blobToBase64(blob),
        width
      };
    } finally {
      decoded.forEach((image) => image.close());
    }
  }
  function pngScreenshotSize(data) {
    const binary = atob(String(data || "").slice(0, 48));
    if (binary.length < 24 || binary.charCodeAt(0) !== 137 || binary.slice(1, 4) !== "PNG") {
      throw new Error("Chrome a produit une tuile qui n'est pas un PNG valide.");
    }
    const uint32 = (offset) => (binary.charCodeAt(offset) << 24 | binary.charCodeAt(offset + 1) << 16 | binary.charCodeAt(offset + 2) << 8 | binary.charCodeAt(offset + 3)) >>> 0;
    return {
      width: uint32(16),
      height: uint32(20)
    };
  }
  function bounded(value, maximum = MAX_SCREENSHOT_HEIGHT) {
    const result = Math.ceil(Number(value));
    if (!Number.isFinite(result) || result < 1 || result > maximum) {
      throw new Error("Invalid screenshot dimension.");
    }
    return result;
  }
  async function blobToBase64(blob) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = "";
    for (let offset = 0; offset < bytes.length; offset += 32768) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + 32768));
    }
    return btoa(binary);
  }

  // apps/extension/lib/embedded-experiences.mjs
  var PROVIDERS = [
    { pattern: /klaviyo/i, provider: "Klaviyo", kind: "marketing" },
    { pattern: /(?:gorgias|intercom|zendesk|crisp\.chat)/i, provider: "Customer chat", kind: "chat" },
    { pattern: /(?:judge\.me|yotpo|reviews\.io|trustpilot)/i, provider: "Reviews", kind: "reviews" },
    { pattern: /(?:youtube(?:-nocookie)?\.com|youtu\.be|vimeo\.com)/i, provider: "Embedded media", kind: "media" },
    { pattern: /(?:stripe|paypal|klarna|afterpay|shopify_pay)/i, provider: "Payment", kind: "payment" },
    { pattern: /(?:recaptcha|hcaptcha|challenges\.cloudflare)/i, provider: "Bot protection", kind: "captcha" },
    { pattern: /(?:auth0|accounts\.google|appleid\.apple)/i, provider: "Authentication", kind: "authentication" }
  ];
  var TECHNICAL_URL = /(?:doubleclick|googletagmanager|google-analytics|facebook\.com\/tr|connect\.facebook|analytics|cookie[-_.]?sync|beacon|pixel)/i;
  function classifyEmbeddedExperience(input) {
    const url = sanitizeEmbeddedUrl(input.url);
    const dimensions = {
      width: boundedNumber(input.width, 0, 2e4),
      height: boundedNumber(input.height, 0, 2e4)
    };
    const area = dimensions.width * dimensions.height;
    const visible = input.visible === true && area >= 1024;
    const providerMatch = PROVIDERS.find(({ pattern }) => pattern.test(`${url} ${input.name || ""} ${input.title || ""}`));
    const technical = TECHNICAL_URL.test(url) || !providerMatch && (/^about:blank$/i.test(url) || dimensions.width <= 2 && dimensions.height <= 2);
    const classification = visible ? "visible-ui" : providerMatch && !technical ? "external-integration" : "technical";
    const captureDecision = classification === "visible-ui" ? "capture" : classification === "external-integration" ? "reconnect" : "exclude";
    return {
      frameId: String(input.frameId || "").slice(0, 128),
      url,
      origin: embeddedOrigin(url),
      name: String(input.name || "").slice(0, 160),
      title: String(input.title || "").slice(0, 200),
      provider: providerMatch?.provider || (technical ? "Technical frame" : "Embedded content"),
      kind: providerMatch?.kind || (technical ? "technical" : "generic"),
      classification,
      captureDecision,
      lifecycle: input.lifecycle || "present",
      visible,
      dimensions,
      signals: {
        textCharacters: boundedNumber(input.textCharacters, 0, 1e6),
        controls: boundedNumber(input.controls, 0, 1e4),
        images: boundedNumber(input.images, 0, 1e4),
        dialogs: boundedNumber(input.dialogs, 0, 1e3)
      }
    };
  }
  function mergeEmbeddedExperienceSnapshots(initial = [], final = []) {
    const merged = /* @__PURE__ */ new Map();
    for (const entry of initial) {
      merged.set(entry.frameId, { ...entry, lifecycle: "present" });
    }
    for (const entry of final) {
      const previous = merged.get(entry.frameId);
      merged.set(entry.frameId, {
        ...previous || {},
        ...entry,
        lifecycle: previous ? "present" : "appeared"
      });
    }
    const finalIds = new Set(final.map((entry) => entry.frameId));
    for (const [frameId, entry] of merged) {
      if (!finalIds.has(frameId)) merged.set(frameId, { ...entry, lifecycle: "disappeared" });
    }
    return [...merged.values()].sort((left, right) => decisionRank(left.captureDecision) - decisionRank(right.captureDecision) || right.dimensions.width * right.dimensions.height - left.dimensions.width * left.dimensions.height).slice(0, 64);
  }
  function publicEmbeddedExperiences(experiences = []) {
    return experiences.map(({ frameId: _frameId, ...experience }) => experience);
  }
  function sanitizeEmbeddedUrl(value) {
    const raw = String(value || "").slice(0, 4096);
    if (!raw) return "";
    try {
      const url = new URL(raw);
      if (!["http:", "https:"].includes(url.protocol)) {
        return raw === "about:blank" || raw === "about:srcdoc" ? raw : "";
      }
      url.username = "";
      url.password = "";
      url.search = "";
      url.hash = "";
      return url.toString().slice(0, 2048);
    } catch {
      return raw === "about:blank" ? raw : "";
    }
  }
  function embeddedOrigin(value) {
    try {
      return new URL(value).origin.slice(0, 512);
    } catch {
      return "";
    }
  }
  function boundedNumber(value, minimum, maximum) {
    const number = Number(value);
    if (!Number.isFinite(number)) return minimum;
    return Math.min(maximum, Math.max(minimum, Math.round(number)));
  }
  function decisionRank(value) {
    return value === "capture" ? 0 : value === "reconnect" ? 1 : 2;
  }

  // apps/extension/lib/technical-frame-isolation.mjs
  function applyTechnicalFrameIsolation(mode = "apply") {
    const stateKey = "__soukCaptureTechnicalFrames";
    const root = globalThis;
    if (mode === "restore") {
      const state2 = root[stateKey];
      state2?.observer?.disconnect?.();
      for (const entry of [...state2?.entries || []].reverse()) {
        try {
          if (!entry.placeholder?.parentNode) continue;
          entry.placeholder.parentNode.replaceChild(entry.replacement, entry.placeholder);
        } catch {
        }
      }
      delete root[stateKey];
      return { restored: state2?.entries?.length || 0 };
    }
    if (root[stateKey]) return { isolated: root[stateKey].entries.length };
    const state = { entries: [], observer: null };
    root[stateKey] = state;
    const shouldIsolate = (element) => {
      if (!(element instanceof HTMLIFrameElement) && !(element instanceof HTMLFrameElement)) return false;
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      const visible = rect.width > 0 && rect.height > 0 && rect.width * rect.height >= 1024 && style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity || 1) > 0 && element.getAttribute("aria-hidden") !== "true";
      return !visible;
    };
    const isolate = (element) => {
      if (!element.isConnected || !shouldIsolate(element)) return;
      element.setAttribute("data-souk-technical-frame", "true");
      const replacement = element.cloneNode(true);
      replacement.removeAttribute("data-souk-technical-frame");
      const placeholder = document.createComment("souk-technical-frame");
      element.parentNode?.replaceChild(placeholder, element);
      state.entries.push({ replacement, placeholder });
    };
    for (const element of document.querySelectorAll("iframe,frame")) isolate(element);
    state.observer = new MutationObserver((records) => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (!(node instanceof Element)) continue;
          isolate(node);
          for (const frame of node.querySelectorAll?.("iframe,frame") || []) isolate(frame);
        }
      }
    });
    state.observer.observe(document, { subtree: true, childList: true });
    return { isolated: state.entries.length };
  }
  function isolateTechnicalFrameOwner() {
    const element = this;
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    const visible = rect.width > 0 && rect.height > 0 && rect.width * rect.height >= 1024 && style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity || 1) > 0 && element.getAttribute("aria-hidden") !== "true";
    if (visible || !element.isConnected) return false;
    const root = element.ownerDocument.defaultView;
    const stateKey = "__soukCaptureTechnicalFrames";
    const state = root[stateKey] || { entries: [], observer: null };
    root[stateKey] = state;
    element.setAttribute("data-souk-technical-frame", "true");
    const replacement = element.cloneNode(true);
    replacement.removeAttribute("data-souk-technical-frame");
    const placeholder = element.ownerDocument.createComment("souk-technical-frame");
    element.parentNode?.replaceChild(placeholder, element);
    state.entries.push({ replacement, placeholder });
    return true;
  }

  // apps/extension/lib/discovery-policy.mjs
  var BLOCKED_PATH = /(?:^|\/)(?:admin|checkout|checkouts|logout|signout|delete|remove|cancel|orders\/[^/]+\/cancel)(?:\/|$)/i;
  var MUTATING_QUERY = /^(?:action|add|buy|checkout|delete|logout|remove|update)$/i;
  var TYPE_PRIORITY = /* @__PURE__ */ new Map([
    ["home", 0],
    ["listing", 1],
    ["product", 2],
    ["cart", 3],
    ["account", 4],
    ["wishlist", 5],
    ["orders", 6],
    ["login", 7],
    ["page", 8]
  ]);
  function safeDiscoveryUrl(input, origin) {
    let url;
    try {
      url = new URL(normalizeSceneUrl(new URL(String(input || ""), origin).toString()));
    } catch {
      return null;
    }
    if (url.origin !== new URL(origin).origin || BLOCKED_PATH.test(url.pathname)) return null;
    for (const key of url.searchParams.keys()) {
      if (MUTATING_QUERY.test(key)) return null;
    }
    return url.toString();
  }
  function canonicalDiscoveryTarget(requested, resolved) {
    try {
      const requestedUrl = new URL(String(requested));
      const resolvedUrl = new URL(normalizeSceneUrl(String(resolved)));
      if (!["http:", "https:"].includes(resolvedUrl.protocol)) return null;
      if (canonicalHostname(requestedUrl.hostname) !== canonicalHostname(resolvedUrl.hostname)) {
        return null;
      }
      return {
        sourceUrl: resolvedUrl.toString(),
        origin: resolvedUrl.origin
      };
    } catch {
      return null;
    }
  }
  function discoveryCandidates(links, origin, visited = [], limit = 20) {
    const seen = new Set(visited.map((entry) => normalizeComparable(entry)));
    const candidates = [];
    for (const link of Array.isArray(links) ? links : []) {
      const value = typeof link === "string" ? link : link?.path;
      const url = safeDiscoveryUrl(value, origin);
      if (!url) continue;
      const comparable = normalizeComparable(url);
      if (seen.has(comparable)) continue;
      seen.add(comparable);
      candidates.push({ url, pageType: inferPageType(url), region: link?.region || "content" });
    }
    return candidates.sort(
      (left, right) => (TYPE_PRIORITY.get(left.pageType) ?? 99) - (TYPE_PRIORITY.get(right.pageType) ?? 99) || (left.region === "navigation" || left.region === "header" ? -1 : 0) - (right.region === "navigation" || right.region === "header" ? -1 : 0) || left.url.localeCompare(right.url)
    ).slice(0, limit);
  }
  function representativeQueue(seedUrl, discovered, existing = [], limit = 16) {
    if (!Number.isFinite(limit) || limit <= 0) return [];
    const queue = [];
    const counts = /* @__PURE__ */ new Map();
    for (const entry of existing) {
      counts.set(entry.pageType, (counts.get(entry.pageType) || 0) + 1);
    }
    const candidates = [
      { url: safeDiscoveryUrl(seedUrl, new URL(seedUrl).origin), pageType: "home", region: "seed" },
      ...discovered
    ];
    for (const candidate of candidates) {
      if (!candidate?.url) continue;
      const cap = candidate.pageType === "product" ? 3 : candidate.pageType === "listing" ? 3 : 1;
      const count = counts.get(candidate.pageType) || 0;
      if (count >= cap) continue;
      counts.set(candidate.pageType, count + 1);
      queue.push(candidate);
      if (queue.length >= limit) break;
    }
    return queue;
  }
  function normalizeComparable(value) {
    try {
      const url = new URL(value);
      return `${url.origin}${url.pathname.replace(/\/+$/, "") || "/"}${url.search}`;
    } catch {
      return String(value || "");
    }
  }
  function canonicalHostname(value) {
    return String(value || "").toLowerCase().replace(/^www\./, "");
  }

  // apps/extension/lib/catalog-extractor.mjs
  var SHOPIFY_CATALOG_EXPRESSION = `async () => {
  const deadline = Date.now() + 100000;
  let requestCount = 0;
  const maxRequests = 160;
  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const json = async (path) => {
    if (Date.now() >= deadline || requestCount >= maxRequests) return null;
    requestCount += 1;
    for (let attempt = 0; attempt < 2; attempt += 1) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      try {
        const response = await fetch(path, {
          credentials: "include",
          headers: { accept: "application/json" },
          signal: controller.signal,
        });
        if ((response.status === 429 || response.status >= 500) && attempt === 0) {
          await delay(500 + Math.floor(Math.random() * 500));
          continue;
        }
        if (!response.ok) return null;
        const type = response.headers.get("content-type") || "";
        if (!type.includes("json")) return null;
        return response.json();
      } catch {
        if (attempt === 0 && Date.now() < deadline) {
          await delay(500);
          continue;
        }
        return null;
      } finally {
        clearTimeout(timer);
      }
    }
    return null;
  };
  const products = [];
  for (let page = 1; page <= 40; page += 1) {
    const payload = await json("/products.json?limit=250&page=" + page);
    const batch = Array.isArray(payload?.products) ? payload.products : [];
    products.push(...batch);
    if (batch.length < 250 || products.length >= 10000) break;
  }
  const collections = [];
  for (let page = 1; page <= 8; page += 1) {
    const payload = await json("/collections.json?limit=250&page=" + page);
    const batch = Array.isArray(payload?.collections) ? payload.collections : [];
    collections.push(...batch);
    if (batch.length < 250 || collections.length >= 2000) break;
  }
  for (const collection of collections.slice(0, 24)) {
    const handles = [];
    for (let page = 1; page <= 4; page += 1) {
      const payload = await json("/collections/" + encodeURIComponent(collection.handle) + "/products.json?limit=250&page=" + page);
      const batch = Array.isArray(payload?.products) ? payload.products : [];
      handles.push(...batch.map((product) => product.handle).filter(Boolean));
      if (batch.length < 250) break;
    }
    collection.products = Array.from(new Set(handles)).map((handle) => ({ handle }));
  }
  const menuRoots = Array.from(document.querySelectorAll("header nav, [role=navigation]")).slice(0, 5);
  const menus = menuRoots.map((root, index) => ({
    id: root.id || "menu-" + (index + 1),
    title: root.getAttribute("aria-label") || "Navigation",
    items: Array.from(root.querySelectorAll(":scope > ul > li, :scope > div > a, :scope > a")).slice(0, 100).map((item) => {
      const anchor = item.matches("a[href]") ? item : item.querySelector("a[href]");
      return {
        title: (anchor?.textContent || item.textContent || "").trim().slice(0, 300),
        url: anchor?.href || "/",
        children: Array.from(item.querySelectorAll("ul a[href]")).slice(0, 100).map((child) => ({
          title: (child.textContent || "").trim().slice(0, 300),
          url: child.href,
        })),
      };
    }),
  }));
  const currency = document.querySelector('meta[property="og:price:currency"]')?.content ||
    globalThis.Shopify?.currency?.active || "EUR";
  return { origin: location.origin, currency, products, collections, menus, capturedAt: new Date().toISOString() };
}`;
  function normalizeShopifyCatalog(raw) {
    const products = (Array.isArray(raw?.products) ? raw.products : []).slice(0, 1e4).map((product) => ({
      id: String(product.id || product.handle),
      handle: String(product.handle || "").trim(),
      title: String(product.title || "").trim(),
      descriptionHtml: sanitizeCatalogHtml(product.body_html || product.description),
      vendor: String(product.vendor || ""),
      productType: String(product.product_type || ""),
      tags: Array.isArray(product.tags) ? product.tags.map(String) : String(product.tags || "").split(",").map((value) => value.trim()).filter(Boolean),
      images: (Array.isArray(product.images) ? product.images : []).map((image) => safeHttpUrl(typeof image === "string" ? image : image?.src)).filter(Boolean),
      options: (Array.isArray(product.options) ? product.options : []).map((option) => ({
        name: String(option.name || ""),
        values: (Array.isArray(option.values) ? option.values : []).map(String)
      })),
      variants: (Array.isArray(product.variants) ? product.variants : []).map((variant) => ({
        id: String(variant.id || ""),
        title: String(variant.title || "Default"),
        available: variant.available !== false,
        price: priceMinorUnits(variant.price),
        compareAtPrice: variant.compare_at_price == null ? null : priceMinorUnits(variant.compare_at_price),
        options: Object.fromEntries((Array.isArray(product.options) ? product.options : []).map((option, index) => [
          String(option.name || `Option ${index + 1}`),
          String(variant[`option${index + 1}`] || "")
        ])),
        image: safeHttpUrl(variant.featured_image?.src || variant.featured_image)
      }))
    })).filter((product) => product.handle && product.title);
    const handles = new Set(products.map((product) => product.handle));
    const collections = (Array.isArray(raw?.collections) ? raw.collections : []).slice(0, 2e3).map((collection) => ({
      id: String(collection.id || collection.handle),
      handle: String(collection.handle || "").trim(),
      title: String(collection.title || "").trim(),
      descriptionHtml: sanitizeCatalogHtml(collection.body_html || collection.description),
      image: safeHttpUrl(collection.image?.src),
      productHandles: (Array.isArray(collection.products) ? collection.products : []).map((product) => String(product.handle || "")).filter((handle) => handles.has(handle))
    })).filter((collection) => collection.handle && collection.title);
    return {
      schemaVersion: 1,
      platform: "shopify",
      origin: new URL(raw.origin).origin,
      currency: String(raw.currency || "EUR").slice(0, 3).toUpperCase(),
      products,
      collections,
      menus: normalizeMenus(raw.menus, new URL(raw.origin).origin),
      capturedAt: raw.capturedAt || (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  function sanitizeCatalogHtml(value) {
    return String(value || "").slice(0, 1e6).replace(/<(script|style|iframe|object|embed|meta|link)\b[^>]*>[\s\S]*?<\/\1>/gi, "").replace(/<(script|style|iframe|object|embed|meta|link)\b[^>]*\/?>/gi, "").replace(/\son[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, "").replace(/\s(?:href|src)\s*=\s*(["'])\s*(?:javascript|data):[\s\S]*?\1/gi, "");
  }
  function safeHttpUrl(value) {
    if (!value) return null;
    try {
      const url = new URL(String(value));
      return ["http:", "https:"].includes(url.protocol) ? url.toString() : null;
    } catch {
      return null;
    }
  }
  function normalizeMenus(value, origin) {
    return (Array.isArray(value) ? value : []).slice(0, 20).map((menu, index) => ({
      id: String(menu?.id || `menu-${index + 1}`).slice(0, 120),
      title: String(menu?.title || "Navigation").slice(0, 300),
      items: (Array.isArray(menu?.items) ? menu.items : []).slice(0, 100).map((item) => ({
        title: String(item?.title || "").slice(0, 300),
        url: safeNavigationUrl(item?.url, origin),
        children: (Array.isArray(item?.children) ? item.children : []).slice(0, 100).map((child) => ({
          title: String(child?.title || "").slice(0, 300),
          url: safeNavigationUrl(child?.url, origin)
        }))
      }))
    }));
  }
  function safeNavigationUrl(value, origin) {
    try {
      const url = new URL(String(value || "/"), origin);
      return url.origin === origin ? `${url.pathname}${url.search}${url.hash}` : "#";
    } catch {
      return "#";
    }
  }
  async function uploadV2Catalog({ baseUrl, token, projectId, catalog }) {
    const data = new TextEncoder().encode(JSON.stringify(catalog));
    const hash = await sha256Hex2(data);
    const initialized = await apiRequest(baseUrl, `/api/capture-v2/projects/${encodeURIComponent(projectId)}/catalog`, token, {
      method: "POST",
      body: JSON.stringify({ byteLength: data.byteLength, hash })
    });
    const chunks = chunkBytes(data);
    for (let index = 0; index < chunks.length; index += 1) {
      await apiRequest(baseUrl, `/api/capture-v2/projects/${encodeURIComponent(projectId)}/catalog/chunks`, token, {
        method: "POST",
        body: JSON.stringify({
          revision: initialized.upload.revision,
          index,
          data: bytesToBase64(chunks[index])
        })
      });
    }
    return apiRequest(baseUrl, `/api/capture-v2/projects/${encodeURIComponent(projectId)}/catalog/complete`, token, {
      method: "POST",
      body: JSON.stringify({ revision: initialized.upload.revision, chunkCount: chunks.length })
    });
  }
  function priceMinorUnits(value) {
    const string = String(value ?? "0").trim();
    if (/^\d+$/.test(string)) return Number(string);
    const amount = Number(string.replace(",", "."));
    return Number.isFinite(amount) ? Math.round(amount * 100) : 0;
  }
  async function sha256Hex2(data) {
    const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", data));
    return Array.from(digest, (byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  // apps/extension/lib/v2-run-state.mjs
  function prepareV2RunState(existing, input, now = (/* @__PURE__ */ new Date()).toISOString()) {
    const { projectId, runId, sourceUrl } = input;
    if (["discovering", "attention_required"].includes(existing?.status)) {
      if (existing.projectId !== projectId || existing.runId !== runId) {
        throw new Error("Another Capture V2 discovery is already running.");
      }
      return { ...existing, status: "discovering", updatedAt: now };
    }
    return {
      version: 2,
      status: "discovering",
      projectId,
      runId,
      sourceUrl,
      origin: new URL(sourceUrl).origin,
      queue: [],
      visited: [],
      observations: [],
      warnings: [],
      tabId: null,
      startedAt: now,
      updatedAt: now
    };
  }
  async function resolveCaptureTab(tabs, payload = {}) {
    const tab = Number.isInteger(payload.tabId) ? await tabs.get(payload.tabId) : (await tabs.query({ active: true, currentWindow: true }))[0];
    if (!tab?.id || !tab.url) throw new Error("No active tab is available to capture.");
    if (!/^https?:\/\//i.test(tab.url)) throw new Error("Open an HTTP(S) page before capturing it.");
    if (payload.expectedOrigin && new URL(tab.url).origin !== payload.expectedOrigin) {
      throw new Error("The dedicated capture tab left the allowed storefront origin.");
    }
    return tab;
  }

  // apps/extension/background.mjs
  var activeCaptures = /* @__PURE__ */ new Set();
  var CDP_TIMEOUT_MS = 2e4;
  var UPLOAD_RETRY_ALARM = "souk-capture-upload-retry";
  var V2_DISCOVERY_ALARM = "souk-capture-v2-discovery";
  var cancelledV2Runs = /* @__PURE__ */ new Set();
  chrome.runtime.onInstalled.addListener(() => {
    chrome.action.setBadgeBackgroundColor({ color: "#ff4e1f" });
  });
  void recoverInterruptedCapture().catch(() => void 0).then(() => resumeDurableUploads()).catch(() => void 0);
  void resumeV2Discovery().catch(() => void 0);
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === UPLOAD_RETRY_ALARM) void resumeDurableUploads();
    if (alarm.name === V2_DISCOVERY_ALARM) void resumeV2Discovery();
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "CAPTURE_CURRENT_TAB") {
      captureCurrentTab(message.payload, sendResponse);
      return true;
    }
    if (message?.type === "GET_ACTIVE_TAB") {
      activeTabSummary().then(sendResponse).catch((error) => sendResponse({ error: error.message }));
      return true;
    }
    return false;
  });
  chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
    if (!isAllowedAppUrl(sender.url)) return;
    if (message?.type === "SOUK_V2_PING") {
      chrome.storage.local.get(["captureV2RunState"]).then(({ captureV2RunState }) => {
        sendResponse({
          ok: true,
          installed: true,
          version: chrome.runtime.getManifest().version,
          busy: captureV2RunState?.status === "discovering",
          projectId: captureV2RunState?.projectId || null
        });
      });
      return true;
    }
    if (message?.type === "SOUK_V2_CONNECT") {
      connectV2FromStudio(message).then(sendResponse).catch((error) => {
        sendResponse({ ok: false, error: error instanceof Error ? error.message : "Unable to connect Capture V2." });
      });
      return true;
    }
    if (message?.type === "SOUK_V2_START_DISCOVERY") {
      startV2Discovery(message).then((state) => {
        sendResponse({ ok: true, busy: true, runId: state.runId });
      }).catch((error) => {
        sendResponse({ ok: false, error: error instanceof Error ? error.message : "Unable to start Capture V2." });
      });
      return true;
    }
    if (message?.type === "SOUK_V2_DISCONNECT") {
      disconnectV2FromStudio().then(sendResponse).catch((error) => {
        sendResponse({ ok: false, error: error instanceof Error ? error.message : "Unable to disconnect Capture V2." });
      });
      return true;
    }
    if (message?.type === "SOUK_PING") {
      sendResponse({ ok: true, installed: true, version: chrome.runtime.getManifest().version });
      return;
    }
    if (message?.type === "SOUK_SELECT_PROJECT" && typeof message.projectId === "string") {
      chrome.storage.local.set({ selectedProjectId: message.projectId }).then(() => sendResponse({ ok: true, success: true }));
      return true;
    }
    if (message?.type === "SOUK_CONNECT") {
      connectFromStudio(message).then(sendResponse).catch((error) => {
        sendResponse({ ok: false, error: error instanceof Error ? error.message : "Unable to connect." });
      });
      return true;
    }
    if (message?.type === "SOUK_DISCONNECT") {
      chrome.storage.local.remove(["accessToken", "refreshToken", "selectedProjectId", "user"]).then(() => sendResponse({ ok: true, disconnected: true }));
      return true;
    }
  });
  async function connectV2FromStudio(message) {
    const token = typeof message.token === "string" ? message.token.trim() : "";
    const projectId = typeof message.projectId === "string" ? message.projectId.trim() : "";
    const sourceUrl = safeDiscoveryUrl(message.sourceUrl, new URL(message.sourceUrl).origin);
    if (!token || !projectId || !sourceUrl) throw new Error("Capture V2 connection details are incomplete.");
    const values = {
      accessToken: token,
      apiBaseUrl: normalizeApiOrigin(message.apiBaseUrl),
      appBaseUrl: normalizeAppOrigin(message.appBaseUrl),
      selectedProjectId: projectId,
      captureV2Project: { projectId, sourceUrl },
      ...typeof message.refreshToken === "string" && message.refreshToken ? { refreshToken: message.refreshToken } : {}
    };
    await chrome.storage.local.set(values);
    return { ok: true, connected: true, projectId };
  }
  async function startV2Discovery(message) {
    const stored = await chrome.storage.local.get([
      "accessToken",
      "apiBaseUrl",
      "captureV2Project",
      "captureV2RunState"
    ]);
    const projectId = String(message.projectId || stored.captureV2Project?.projectId || "");
    const sourceUrl = String(message.sourceUrl || stored.captureV2Project?.sourceUrl || "");
    const runId = String(message.runId || "");
    if (!stored.accessToken || !projectId || !sourceUrl || !runId) {
      throw new Error("Connect the V2 extension and create a discovery run first.");
    }
    const existing = stored.captureV2RunState;
    const state = prepareV2RunState(existing, { projectId, runId, sourceUrl });
    cancelledV2Runs.delete(runId);
    await chrome.storage.local.set({ captureV2RunState: state });
    await chrome.alarms.create(V2_DISCOVERY_ALARM, { delayInMinutes: 1 });
    void driveV2Discovery(state).catch(() => void 0);
    return state;
  }
  async function disconnectV2FromStudio() {
    const { captureV2RunState } = await chrome.storage.local.get(["captureV2RunState"]);
    if (captureV2RunState?.runId) cancelledV2Runs.add(captureV2RunState.runId);
    await chrome.alarms.clear(V2_DISCOVERY_ALARM);
    if (captureV2RunState?.tabId) {
      await chrome.debugger.detach({ tabId: captureV2RunState.tabId }).catch(() => void 0);
    }
    await chrome.storage.local.remove([
      "accessToken",
      "refreshToken",
      "selectedProjectId",
      "captureV2Project",
      "captureV2RunState"
    ]);
    await chrome.action.setBadgeText({ text: "" });
    return { ok: true, disconnected: true };
  }
  async function resumeV2Discovery() {
    const { captureV2RunState } = await chrome.storage.local.get(["captureV2RunState"]);
    if (captureV2RunState?.status !== "discovering") return null;
    return driveV2Discovery(captureV2RunState);
  }
  var activeV2Discovery = null;
  function driveV2Discovery(input) {
    if (activeV2Discovery) return activeV2Discovery;
    activeV2Discovery = executeV2Discovery(input).finally(() => {
      activeV2Discovery = null;
    });
    return activeV2Discovery;
  }
  async function executeV2Discovery(input) {
    const auth = await chrome.storage.local.get(["accessToken", "apiBaseUrl"]);
    const baseUrl = normalizeApiOrigin(auth.apiBaseUrl);
    const token = auth.accessToken;
    const state = {
      ...input,
      queue: Array.isArray(input.queue) ? input.queue : [],
      visited: Array.isArray(input.visited) ? input.visited : [],
      observations: Array.isArray(input.observations) ? input.observations : [],
      warnings: Array.isArray(input.warnings) ? input.warnings : []
    };
    try {
      let tab = state.tabId ? await chrome.tabs.get(state.tabId).catch(() => null) : null;
      if (!tab) {
        tab = await findOrCreateV2Tab(state.sourceUrl, state.origin);
        state.tabId = tab.id;
      }
      const initialNavigation = await navigateV2Tab(tab.id, state.sourceUrl);
      const canonicalTarget = canonicalDiscoveryTarget(state.sourceUrl, initialNavigation.url);
      if (!canonicalTarget) {
        throw new Error(`The storefront redirected outside its canonical host: ${initialNavigation.url || state.sourceUrl}`);
      }
      state.sourceUrl = canonicalTarget.sourceUrl;
      state.origin = canonicalTarget.origin;
      if (!state.queue.length && !state.visited.length) {
        state.queue = representativeQueue(state.sourceUrl, [
          { url: `${state.origin}/collections/all`, pageType: "listing", region: "seed" },
          { url: `${state.origin}/search`, pageType: "listing", region: "seed" },
          { url: `${state.origin}/cart`, pageType: "cart", region: "seed" },
          { url: `${state.origin}/account`, pageType: "account", region: "seed" },
          { url: `${state.origin}/pages/wishlist`, pageType: "wishlist", region: "seed" }
        ], [], 16);
      }
      if (!state.catalogUploaded) {
        try {
          const catalog = await extractV2Catalog(tab.id, state.origin);
          const uploaded = await uploadV2Catalog({
            baseUrl,
            token,
            projectId: state.projectId,
            catalog
          });
          state.catalogUploaded = true;
          state.catalog = uploaded.catalog;
          if (!catalog.products.length) {
            state.warnings.push("Shopify did not expose products.json; captured product templates remain available, but the local catalog is empty.");
          }
        } catch (error) {
          state.warnings.push(`Catalog extraction needs attention: ${error instanceof Error ? error.message : "unknown error"}`);
          state.status = "attention_required";
          await persistV2State(state);
          await updateV2Run(baseUrl, token, state, {
            status: "attention_required",
            heartbeat: true,
            currentUrl: state.sourceUrl,
            warnings: state.warnings
          });
          await chrome.alarms.clear(V2_DISCOVERY_ALARM);
          await chrome.action.setBadgeText({ text: "!" });
          return state;
        }
        await persistV2State(state);
      }
      while (state.queue.length && state.visited.length < 16) {
        if (cancelledV2Runs.has(state.runId)) return state;
        const candidate = state.queue.shift();
        const target = safeDiscoveryUrl(candidate?.url, state.origin);
        if (!target || state.visited.some((entry) => entry.url === target)) continue;
        await updateV2Run(baseUrl, token, state, {
          status: "discovering",
          heartbeat: true,
          currentUrl: target,
          warnings: state.warnings
        });
        const navigated = await navigateV2Tab(tab.id, target);
        const finalUrl = safeDiscoveryUrl(navigated.url, state.origin);
        if (!finalUrl) {
          state.warnings.push(`Skipped a redirect outside the storefront: ${target}`);
          await persistV2State(state);
          continue;
        }
        const requestedType = candidate.pageType || inferPageType(target);
        const finalType = inferPageType(finalUrl);
        const loginRedirect = ["account", "orders", "wishlist"].includes(requestedType) && finalType === "login";
        if (loginRedirect) {
          const observation2 = {
            url: finalUrl,
            kind: requestedType,
            state: "login-required",
            title: navigated.title || requestedType,
            authenticated: false,
            captureId: null,
            discoveredAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          state.observations = [
            ...state.observations.filter((entry) => !(entry.url === observation2.url && entry.kind === observation2.kind && entry.state === observation2.state)),
            observation2
          ];
          state.queue.unshift(candidate);
          state.status = "attention_required";
          state.warnings.push(`Sign in is still required for ${requestedType}: ${target}`);
          await updateV2Run(baseUrl, token, state, {
            status: "attention_required",
            heartbeat: true,
            currentUrl: finalUrl,
            observations: [observation2],
            warnings: state.warnings
          });
          await persistV2State(state);
          await chrome.alarms.clear(V2_DISCOVERY_ALARM);
          await chrome.action.setBadgeText({ text: "!" });
          return state;
        }
        await chrome.tabs.update(tab.id, { active: true });
        const captured = await captureActiveV2Tab({
          tabId: tab.id,
          expectedOrigin: state.origin,
          baseUrl,
          token,
          projectId: state.projectId,
          pageType: requestedType,
          stateLabel: "default"
        });
        if (captured.error) throw new Error(captured.error);
        const observation = {
          url: finalUrl,
          kind: requestedType,
          state: "default",
          title: navigated.title || "",
          authenticated: ["account", "orders", "wishlist"].includes(requestedType) ? true : null,
          captureId: captured.capture?.id || captured.id || null,
          discoveredAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        state.visited.push({ url: finalUrl, pageType: requestedType });
        state.observations.push(observation);
        const discovered = discoveryCandidates(
          captured.designManifest?.structure?.links || [],
          state.origin,
          [...state.visited.map((entry) => entry.url), ...state.queue.map((entry) => entry.url)],
          100
        );
        state.queue.push(...representativeQueue(state.sourceUrl, discovered, [
          ...state.visited,
          ...state.queue
        ], Math.max(0, 16 - state.visited.length - state.queue.length)));
        await updateV2Run(baseUrl, token, state, {
          status: "discovering",
          heartbeat: true,
          currentUrl: finalUrl,
          observations: [observation],
          warnings: state.warnings
        });
        await persistV2State(state);
      }
      state.status = "review_ready";
      state.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      await persistV2State(state);
      await updateV2Run(baseUrl, token, state, {
        status: "review_ready",
        heartbeat: true,
        currentUrl: null,
        warnings: state.warnings
      });
      await chrome.alarms.clear(V2_DISCOVERY_ALARM);
      await chrome.action.setBadgeText({ text: "\u2713" });
      return state;
    } catch (error) {
      state.status = "attention_required";
      state.warnings.push(error instanceof Error ? error.message : "Capture V2 discovery stopped.");
      state.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      await persistV2State(state);
      await updateV2Run(baseUrl, token, state, {
        status: "attention_required",
        heartbeat: true,
        currentUrl: null,
        warnings: state.warnings
      }).catch(() => void 0);
      await chrome.action.setBadgeText({ text: "!" });
      await chrome.alarms.clear(V2_DISCOVERY_ALARM);
      throw error;
    }
  }
  async function persistV2State(state) {
    state.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    await chrome.storage.local.set({ captureV2RunState: state });
  }
  async function updateV2Run(baseUrl, token, state, payload) {
    let lastError;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      try {
        return await apiRequest(
          baseUrl,
          `/api/capture-v2/projects/${encodeURIComponent(state.projectId)}/runs/${encodeURIComponent(state.runId)}`,
          token,
          { method: "POST", body: JSON.stringify(payload) }
        );
      } catch (error) {
        lastError = error;
        if (attempt < 2) await new Promise((resolve) => setTimeout(resolve, 400 * 2 ** attempt));
      }
    }
    throw lastError;
  }
  async function findOrCreateV2Tab(sourceUrl, origin) {
    return chrome.tabs.create({ url: sourceUrl, active: true });
  }
  async function navigateV2Tab(tabId, url) {
    return new Promise((resolve, reject) => {
      let settled = false;
      const cleanup = () => {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
      };
      const finish = async (tab) => {
        if (settled) return;
        settled = true;
        cleanup();
        await new Promise((done) => setTimeout(done, 800));
        const current = await chrome.tabs.get(tabId).catch(() => tab);
        resolve(current);
      };
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        cleanup();
        reject(new Error(`The storefront did not finish loading: ${url}`));
      }, 3e4);
      const listener = (updatedTabId, changeInfo, tab) => {
        if (updatedTabId !== tabId || changeInfo.status !== "complete") return;
        void finish(tab);
      };
      chrome.tabs.onUpdated.addListener(listener);
      chrome.tabs.update(tabId, { url, active: true }).then((target) => {
        if (target.status === "complete") void finish(target);
      }).catch((error) => {
        if (settled) return;
        settled = true;
        cleanup();
        reject(error);
      });
    });
  }
  async function extractV2Catalog(tabId, origin) {
    let attached = false;
    try {
      await chrome.debugger.attach({ tabId }, "1.3");
      attached = true;
      const response = await sendCdp(tabId, "Runtime.evaluate", {
        expression: `(${SHOPIFY_CATALOG_EXPRESSION})()`,
        awaitPromise: true,
        returnByValue: true
      }, 12e4);
      if (response?.exceptionDetails || !response?.result?.value) {
        throw new Error("Shopify catalog endpoints did not return usable JSON.");
      }
      const catalog = normalizeShopifyCatalog(response.result.value);
      if (new URL(catalog.origin).origin !== origin) throw new Error("Catalog origin mismatch.");
      return catalog;
    } finally {
      if (attached) await chrome.debugger.detach({ tabId }).catch(() => void 0);
    }
  }
  function captureActiveV2Tab(payload) {
    return new Promise((resolve) => captureCurrentTab(payload, resolve));
  }
  async function captureCurrentTab(payload, sendResponse) {
    let tabId;
    let attached = false;
    try {
      const tab = await resolveCaptureTab(chrome.tabs, payload);
      tabId = tab.id;
      if (activeCaptures.has(tabId)) throw new Error("A capture of this tab is already in progress.");
      activeCaptures.add(tabId);
      await chrome.action.setBadgeText({ tabId, text: "\u2026" });
      await chrome.debugger.attach({ tabId }, "1.3");
      attached = true;
      const captureIdentity = await readCaptureIdentity(tabId);
      const initialEmbeddedExperiences = await inspectEmbeddedExperiences(tabId);
      const intelligenceResult = await sendCdp(tabId, "Runtime.evaluate", {
        expression: `(${prepareAndAnalyzePage.toString()})(${JSON.stringify({
          maxDurationMs: 8e3,
          maxIterations: 18,
          settleDelayMs: 180,
          stableRounds: 3,
          sampleLimit: 2e3
        })})`,
        awaitPromise: true,
        returnByValue: true
      });
      if (intelligenceResult?.exceptionDetails || !intelligenceResult?.result?.value) {
        throw new Error("The page analysis could not be completed.");
      }
      const designManifest = intelligenceResult.result.value;
      const finalEmbeddedExperiences = await inspectEmbeddedExperiences(tabId);
      designManifest.embeddedExperiences = publicEmbeddedExperiences(
        mergeEmbeddedExperienceSnapshots(
          initialEmbeddedExperiences,
          finalEmbeddedExperiences
        )
      );
      let fidelityApplied = false;
      let privacyApplied = [];
      let result;
      let renderSnapshotResult;
      let screenshotResult;
      let screenshotMetadata;
      let layoutMetrics;
      let captureEpochStarted = false;
      let identityContexts = [];
      let technicalFramesIsolated = false;
      try {
        fidelityApplied = true;
        await chrome.storage.local.set({ captureRecovery: { tabId, startedAt: Date.now() } });
        const fidelityResult = await sendCdp(tabId, "Runtime.evaluate", {
          expression: `(${applySnapshotFidelity.toString()})("apply")`,
          awaitPromise: true,
          returnByValue: true
        });
        if (fidelityResult?.exceptionDetails) {
          throw new Error("Full-page rendering preparation failed.");
        }
        const frameIsolation = await sendCdp(tabId, "Runtime.evaluate", {
          expression: `(${applyTechnicalFrameIsolation.toString()})("apply")`,
          returnByValue: true
        });
        if (frameIsolation?.exceptionDetails) {
          throw new Error("Chrome could not isolate invisible technical frames.");
        }
        await isolateInvisibleFrameOwners(tabId);
        technicalFramesIsolated = true;
        const privacyContexts = await applyPrivacyToFrames(tabId, "mask");
        privacyApplied = privacyContexts;
        if (privacyContexts.some((entry) => entry.result?.exceptionDetails || entry.result?.result?.value?.capped)) {
          throw new Error("The page contains too many private fields to capture safely.");
        }
        identityContexts = await applyNodeIdentityToFrames(tabId, "apply");
        if (identityContexts.some((entry) => entry.result?.exceptionDetails || entry.result?.result?.value?.capped)) {
          throw new Error("The page contains too many nodes to preserve stable capture identities.");
        }
        await stabilizePrivacyCoverage(tabId, privacyContexts);
        await beginCaptureEpoch(tabId);
        captureEpochStarted = true;
        try {
          const protectedSnapshots = await captureProtectedSnapshots(tabId, privacyContexts);
          renderSnapshotResult = protectedSnapshots.renderSnapshot;
          result = protectedSnapshots.mhtmlSnapshot;
        } catch (error) {
          throw new Error(
            `Chrome did not provide the required Render IR v2 (${error instanceof Error ? error.message : "DOMSnapshot unavailable"}).`
          );
        }
        const linkedAssets = await sendCdp(tabId, "Runtime.evaluate", {
          expression: `Array.from(document.querySelectorAll('link[rel~="icon"],link[rel$="-icon"]'))
          .map((link) => link.href)
          .filter((url) => /^https?:\\/\\//i.test(url))`,
          returnByValue: true
        });
        const renderedImageSources = await sendCdp(tabId, "Runtime.evaluate", {
          expression: `Array.from(document.images)
          .filter((image) => image.naturalWidth > 0 && /^https?:\\/\\//i.test(image.currentSrc))
          .map((image) => image.currentSrc)`,
          returnByValue: true
        });
        const renderedImageUrls = requireCdpValue(
          renderedImageSources,
          Array.isArray,
          "Chrome could not inventory the rendered page images."
        );
        const linkedAssetUrls = requireCdpValue(
          linkedAssets,
          Array.isArray,
          "Chrome could not inventory the page icons."
        );
        const exactResourceUrls = currentSourceUrls(
          renderSnapshotResult,
          renderedImageUrls
        );
        const missingCurrentSources = missingMhtmlLocations(result?.data || "", exactResourceUrls);
        if (missingCurrentSources.length) {
          const exactResources = await loadExactResources(
            tabId,
            captureIdentity.frameId,
            missingCurrentSources
          );
          result = {
            ...result,
            data: appendMhtmlResources(result?.data || "", exactResources)
          };
        }
        const missingOptionalAssets = missingMhtmlLocations(
          result?.data || "",
          linkedAssetUrls
        );
        if (missingOptionalAssets.length) {
          const optionalResources = await loadExactResources(
            tabId,
            captureIdentity.frameId,
            missingOptionalAssets,
            { allowUnavailable: true }
          );
          result = {
            ...result,
            data: appendMhtmlResources(result?.data || "", optionalResources)
          };
        }
        if (missingMhtmlLocations(result?.data || "", exactResourceUrls).length) {
          throw new Error("Chrome did not archive every exact page asset.");
        }
        layoutMetrics = await sendCdp(tabId, "Page.getLayoutMetrics");
        const contentSize2 = layoutMetrics?.cssContentSize || layoutMetrics?.contentSize || {};
        const mutations = await endCaptureEpoch(tabId);
        captureEpochStarted = false;
        if (mutations.visual > 0) {
          throw new Error("The page changed during capture. Wait for it to stabilize, then capture it again.");
        }
        let lastVisibleCaptureAt = 0;
        const captureTile = async (scrollY) => {
          await sendCdp(tabId, "Runtime.evaluate", {
            expression: `new Promise((resolve) => {
            window.scrollTo({ top: ${scrollY}, left: 0, behavior: "instant" });
            requestAnimationFrame(() => requestAnimationFrame(() => resolve(window.scrollY)));
          })`,
            awaitPromise: true,
            returnByValue: true
          });
          await chrome.tabs.update(tabId, { active: true });
          const throttleMs = Math.max(0, lastVisibleCaptureAt + 600 - Date.now());
          if (throttleMs) {
            await new Promise((resolve) => setTimeout(resolve, throttleMs));
          }
          const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
            format: "png"
          });
          lastVisibleCaptureAt = Date.now();
          const marker = "base64,";
          const markerIndex = String(dataUrl || "").indexOf(marker);
          const data = markerIndex >= 0 ? dataUrl.slice(markerIndex + marker.length) : "";
          if (!data) throw new Error("Chrome n'a produit aucune tuile screenshot.");
          return data;
        };
        const firstTile = await captureTile(0);
        const firstTileSize = pngScreenshotSize(firstTile);
        const screenshotPlan = screenshotTilePlan({
          viewportWidth: firstTileSize.width,
          viewportHeight: firstTileSize.height,
          documentHeight: Number(contentSize2.height) || designManifest.scroll?.finalDocumentHeight || 800
        });
        const tileCaptures = [firstTile];
        for (const tile of screenshotPlan.tiles.slice(1)) {
          await setFloatingElementsHidden(tabId, true);
          tileCaptures.push(await captureTile(tile.scrollY));
        }
        await setFloatingElementsHidden(tabId, false);
        const stitched = await stitchScreenshotTiles(screenshotPlan, tileCaptures);
        screenshotResult = { data: stitched.data };
        screenshotMetadata = {
          width: stitched.width,
          height: screenshotPlan.height,
          fullPage: screenshotPlan.fullPage,
          truncated: screenshotPlan.truncated
        };
      } finally {
        try {
          if (captureEpochStarted) await endCaptureEpoch(tabId).catch(() => void 0);
          await setFloatingElementsHidden(tabId, false).catch(() => void 0);
          let restorationError;
          if (identityContexts.length) {
            await restoreNodeIdentityContexts(tabId, identityContexts).catch((error) => {
              restorationError = error;
            });
          }
          if (privacyApplied.length) {
            await restorePrivacyContexts(tabId, privacyApplied).catch((error) => {
              restorationError ||= error;
            });
          }
          if (restorationError) throw restorationError;
        } finally {
          if (technicalFramesIsolated) {
            await sendCdp(tabId, "Runtime.evaluate", {
              expression: `(${applyTechnicalFrameIsolation.toString()})("restore")`,
              returnByValue: true
            }, 5e3).catch(() => void 0);
          }
          if (fidelityApplied) {
            await sendCdp(tabId, "Runtime.evaluate", {
              expression: `(${applySnapshotFidelity.toString()})("restore")`,
              awaitPromise: true,
              returnByValue: true
            });
          }
          await chrome.storage.local.remove(["captureRecovery"]);
        }
      }
      if (!result?.data) throw new Error("Chrome n'a produit aucun snapshot MHTML.");
      if (!renderSnapshotResult?.documents?.length || !renderSnapshotResult?.strings?.length) {
        throw new Error("Chrome n'a produit aucun Render IR exploitable.");
      }
      if (!screenshotResult?.data) throw new Error("Chrome n'a produit aucun screenshot PNG.");
      await assertCaptureIdentity(tabId, captureIdentity);
      const dimensions = await sendCdp(tabId, "Runtime.evaluate", {
        expression: "({width: window.innerWidth, height: window.innerHeight, title: document.title, url: location.href})",
        returnByValue: true
      }).catch(() => null);
      await chrome.debugger.detach({ tabId });
      attached = false;
      const page = dimensions?.result?.value || {};
      const contentSize = layoutMetrics?.cssContentSize || layoutMetrics?.contentSize || {};
      const captureViewport = resolveCaptureViewport({
        page,
        tab,
        designManifest,
        screenshotMetadata
      });
      const controls = (designManifest.structure?.interactions || []).map((interaction) => ({
        role: interaction.trigger?.role || interaction.trigger?.tag || "control",
        name: interaction.trigger?.name || interaction.trigger?.ariaLabel || "",
        locator: interaction.trigger?.selector || "",
        targetUrl: interaction.targetPath ? new URL(interaction.targetPath, page.url || tab.url).toString() : "",
        bounds: interaction.trigger?.bounds,
        visible: true,
        disabled: interaction.trigger?.disabled === true,
        action: interaction.action
      }));
      const renderArtifact = await createCaptureArtifactV2({
        snapshot: renderSnapshotResult,
        page: {
          url: page.url || tab.url,
          title: page.title || tab.title || "",
          pageType: payload.pageType || "page",
          stateLabel: payload.stateLabel || "default"
        },
        environment: {
          viewportWidth: captureViewport.width,
          viewportHeight: captureViewport.height,
          documentWidth: Number(contentSize.width) || captureViewport.width,
          documentHeight: Number(contentSize.height) || designManifest.scroll?.finalDocumentHeight || 800,
          deviceScaleFactor: designManifest.environment?.deviceScaleFactor || 1,
          locale: designManifest.environment?.locale || "",
          colorScheme: designManifest.environment?.colorScheme || "light",
          reducedMotion: designManifest.environment?.reducedMotion === true
        },
        controls,
        intelligence: designManifest,
        capabilities: {
          domSnapshot: true,
          privacyMasking: true,
          includeDOMRects: true,
          includePaintOrder: true,
          includeBlendedBackgroundColors: true,
          includeTextColorOpacities: true
        }
      });
      const completed = await uploadSnapshot({
        baseUrl: payload.baseUrl,
        token: payload.token,
        projectId: payload.projectId,
        metadata: {
          url: page.url || tab.url,
          title: page.title || tab.title || "",
          pageType: payload.pageType || "page",
          stateLabel: payload.stateLabel || "default",
          viewportWidth: captureViewport.width,
          viewportHeight: captureViewport.height,
          designManifest
        },
        snapshot: result.data,
        screenshot: base64ToBytes(screenshotResult.data),
        screenshotMetadata,
        renderArtifact,
        onProgress: (progress) => chrome.action.setBadgeText({ tabId: tab.id, text: String(Math.max(1, Math.round(progress / 10))) })
      }).catch(async (error) => {
        await scheduleUploadRetry().catch(() => void 0);
        throw error;
      });
      await chrome.action.setBadgeText({ tabId: tab.id, text: "\u2713" });
      setTimeout(() => chrome.action.setBadgeText({ tabId: tab.id, text: "" }), 2500);
      sendResponse({
        success: true,
        ...completed,
        designManifest,
        renderArtifact: {
          version: renderArtifact.version,
          sha256: renderArtifact.integrity.sha256,
          byteLength: renderArtifact.integrity.byteLength
        }
      });
    } catch (error) {
      if (tabId && attached) {
        const detached = await chrome.debugger.detach({ tabId }).then(() => true).catch(() => false);
        if (detached) attached = false;
      }
      sendResponse({ error: error instanceof Error ? error.message : "The capture failed." });
    } finally {
      if (tabId && attached) await chrome.debugger.detach({ tabId }).catch(() => void 0);
      if (tabId) activeCaptures.delete(tabId);
    }
  }
  async function resumeDurableUploads() {
    const results = await resumePendingUploads();
    if (results.some((result) => result?.error)) {
      await scheduleUploadRetry();
    } else {
      await chrome.alarms.clear(UPLOAD_RETRY_ALARM);
      await chrome.storage.local.remove(["uploadRetryAttempt"]);
    }
    return results;
  }
  async function scheduleUploadRetry() {
    const stored = await chrome.storage.local.get(["uploadRetryAttempt"]);
    const attempt = Math.min(8, Math.max(0, Number(stored.uploadRetryAttempt) || 0) + 1);
    const delayInMinutes = Math.min(60, 2 ** (attempt - 1) + Math.random());
    await chrome.storage.local.set({ uploadRetryAttempt: attempt });
    await chrome.alarms.create(UPLOAD_RETRY_ALARM, { delayInMinutes });
    await chrome.action.setBadgeText({ text: "!" }).catch(() => void 0);
  }
  async function activeTabSummary() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab ? { id: tab.id, url: tab.url || "", title: tab.title || "", width: tab.width || 0, height: tab.height || 0 } : null;
  }
  async function connectFromStudio(message) {
    const accessToken = typeof message.accessToken === "string" ? message.accessToken.trim() : "";
    if (!accessToken) throw new Error("Jeton client manquant.");
    const values = {
      accessToken,
      apiBaseUrl: normalizeApiOrigin(message.apiBaseUrl),
      appBaseUrl: normalizeAppOrigin(message.appBaseUrl),
      ...typeof message.refreshToken === "string" && message.refreshToken ? { refreshToken: message.refreshToken } : {},
      ...typeof message.projectId === "string" && message.projectId ? { selectedProjectId: message.projectId } : {}
    };
    await chrome.storage.local.set(values);
    return { ok: true, connected: true };
  }
  async function sendCdp(tabId, method, params = {}, timeoutMs = CDP_TIMEOUT_MS) {
    let timer;
    try {
      return await Promise.race([
        chrome.debugger.sendCommand({ tabId }, method, params),
        new Promise((_, reject) => {
          timer = setTimeout(
            () => reject(new Error(`Chrome did not respond to ${method} before the timeout.`)),
            timeoutMs
          );
        })
      ]);
    } finally {
      if (timer) clearTimeout(timer);
    }
  }
  function requireCdpValue(response, predicate, message) {
    const value = response?.result?.value;
    if (response?.exceptionDetails || !predicate(value)) throw new Error(message);
    return value;
  }
  async function setFloatingElementsHidden(tabId, hidden) {
    return sendCdp(tabId, "Runtime.evaluate", {
      expression: `(() => {
      const key = "__soukCaptureFloatingElements";
      if (${hidden ? "true" : "false"}) {
        if (globalThis[key]) return globalThis[key].length;
        const entries = [];
        for (const element of document.querySelectorAll("body *")) {
          const position = getComputedStyle(element).position;
          if (position !== "fixed" && position !== "sticky") continue;
          entries.push({
            element,
            value: element.style.getPropertyValue("visibility"),
            priority: element.style.getPropertyPriority("visibility"),
          });
          element.style.setProperty("visibility", "hidden", "important");
        }
        globalThis[key] = entries;
        return entries.length;
      }
      const entries = globalThis[key] || [];
      for (const entry of entries) {
        if (!entry.element?.style) continue;
        if (entry.value) entry.element.style.setProperty("visibility", entry.value, entry.priority || "");
        else entry.element.style.removeProperty("visibility");
      }
      delete globalThis[key];
      return entries.length;
    })()`,
      returnByValue: true
    });
  }
  async function loadExactResources(tabId, frameId, urls, { allowUnavailable = false } = {}) {
    await Promise.all([
      sendCdp(tabId, "Network.enable"),
      sendCdp(tabId, "Page.enable")
    ]);
    const resourceTree = await sendCdp(tabId, "Page.getResourceTree");
    const cachedResources = resourceEntries(resourceTree?.frameTree);
    const resources = [];
    for (const url of assertMhtmlResourceCount(urls)) {
      try {
        const cached = cachedResources.get(url);
        if (cached) {
          const content = await sendCdp(tabId, "Page.getResourceContent", {
            frameId: cached.frameId,
            url
          }, 6e4).catch(() => null);
          if (typeof content?.content === "string") {
            const bytes2 = content.base64Encoded ? base64ToBytes(content.content) : new TextEncoder().encode(content.content);
            if (bytes2.byteLength > 12 * 1024 * 1024) {
              throw new Error(`The exact asset ${url} exceeds 12 MB.`);
            }
            resources.push({
              url,
              mimeType: cached.mimeType,
              bytes: bytes2
            });
            continue;
          }
        }
        const loaded = await sendCdp(tabId, "Network.loadNetworkResource", {
          frameId,
          url,
          options: {
            disableCache: false,
            includeCredentials: true
          }
        }, 6e4);
        const resource = loaded?.resource;
        if (!resource?.success || !resource.stream) {
          throw new Error(`Chrome n'a pas pu archiver l'asset exact ${url}.`);
        }
        const chunks = [];
        let byteLength = 0;
        try {
          while (true) {
            const part = await sendCdp(tabId, "IO.read", {
              handle: resource.stream,
              size: 1024 * 1024
            }, 6e4);
            const bytes2 = part?.base64Encoded ? base64ToBytes(part.data || "") : new TextEncoder().encode(part?.data || "");
            byteLength += bytes2.byteLength;
            if (byteLength > 12 * 1024 * 1024) {
              throw new Error(`The exact asset ${url} exceeds 12 MB.`);
            }
            chunks.push(bytes2);
            if (part?.eof) break;
          }
        } finally {
          await sendCdp(tabId, "IO.close", { handle: resource.stream }).catch(() => void 0);
        }
        const bytes = new Uint8Array(byteLength);
        let offset = 0;
        for (const chunk of chunks) {
          bytes.set(chunk, offset);
          offset += chunk.byteLength;
        }
        const headers = resource.headers || {};
        resources.push({
          url,
          mimeType: resource.mimeType || headers["content-type"] || headers["Content-Type"] || "",
          bytes
        });
      } catch (error) {
        if (allowUnavailable) continue;
        throw error;
      }
    }
    return resources;
  }
  function resourceEntries(frameTree, entries = /* @__PURE__ */ new Map()) {
    const frameId = frameTree?.frame?.id;
    if (frameId) {
      for (const resource of frameTree.resources || []) {
        if (/^https?:\/\//i.test(resource?.url || "")) {
          entries.set(resource.url, {
            frameId,
            mimeType: resource.mimeType || ""
          });
        }
      }
    }
    for (const child of frameTree?.childFrames || []) resourceEntries(child, entries);
    return entries;
  }
  async function readCaptureIdentity(tabId) {
    const [tree, location2] = await Promise.all([
      sendCdp(tabId, "Page.getFrameTree"),
      sendCdp(tabId, "Runtime.evaluate", {
        expression: "location.href",
        returnByValue: true
      })
    ]);
    return {
      frameId: tree?.frameTree?.frame?.id || "",
      loaderId: tree?.frameTree?.frame?.loaderId || "",
      url: String(location2?.result?.value || "")
    };
  }
  async function assertCaptureIdentity(tabId, expected) {
    const current = await readCaptureIdentity(tabId);
    if (!expected.frameId || current.frameId !== expected.frameId || current.loaderId !== expected.loaderId || current.url !== expected.url) {
      throw new Error("The page navigated during capture. Return to the intended scene and capture it again.");
    }
  }
  async function beginCaptureEpoch(tabId) {
    const result = await sendCdp(tabId, "Runtime.evaluate", {
      expression: `(() => {
      window.__soukCaptureEpoch?.disconnect?.();
      window.__soukCaptureEpochMutations = { visual: 0 };
      const isRendered = (element) => {
        if (!(element instanceof Element) || !element.isConnected) return false;
        const style = getComputedStyle(element);
        if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) return false;
        const rect = element.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0;
      };
      const nonVisualElement = (node) => node instanceof Element &&
        (/^(?:SCRIPT|META|TEMPLATE|NOSCRIPT)$/.test(node.tagName) ||
          node.hasAttribute("data-souk-technical-frame"));
      const stylesheetElement = (node) => node instanceof Element && (
        node.tagName === "STYLE" ||
        (node.tagName === "LINK" && String(node.rel || "").split(/s+/).includes("stylesheet"))
      );
      const observer = new MutationObserver((records) => {
        const state = window.__soukCaptureEpochMutations;
        for (const record of records) {
          let visual = false;
          if (record.type === "characterData") {
            visual = stylesheetElement(record.target.parentElement) ||
              isRendered(record.target.parentElement);
          } else if (record.type === "attributes") {
            const attribute = record.attributeName || "";
            const changesVisibility = /^(?:class|style|hidden|open|aria-hidden)$/.test(attribute);
            visual = /^(?:class|style|hidden|open|src|srcset|width|height|aria-hidden)$/.test(attribute) &&
              (changesVisibility || stylesheetElement(record.target) || isRendered(record.target));
          } else if (record.type === "childList") {
            const changedNodes = [...record.addedNodes, ...record.removedNodes]
              .filter((node) => !nonVisualElement(node));
            visual = changedNodes.some(stylesheetElement) ||
              (changedNodes.length > 0 && (
                isRendered(record.target) ||
                [...record.removedNodes].some((node) => node instanceof Element)
              ));
          }
          if (!visual) continue;
          state.visual += 1;
        }
      });
      observer.observe(document, {
        subtree: true,
        childList: true,
        attributes: true,
        attributeOldValue: true,
        characterData: true,
      });
      window.__soukCaptureEpoch = observer;
      return true;
    })()`,
      returnByValue: true
    });
    if (result?.exceptionDetails || result?.result?.value !== true) {
      throw new Error("Chrome could not lock the page's visual state.");
    }
  }
  async function endCaptureEpoch(tabId) {
    const result = await sendCdp(tabId, "Runtime.evaluate", {
      expression: `(() => {
      const state = window.__soukCaptureEpochMutations || { visual: 0 };
      window.__soukCaptureEpoch?.disconnect?.();
      delete window.__soukCaptureEpoch;
      delete window.__soukCaptureEpochMutations;
      return state;
    })()`,
      returnByValue: true
    });
    if (result?.exceptionDetails) throw new Error("Chrome could not validate the page's visual state.");
    const value = result?.result?.value || {};
    return {
      visual: Number(value.visual || 0)
    };
  }
  function frameIds(frameTree) {
    const ids = [];
    const visit = (entry) => {
      if (entry?.frame?.id) ids.push(entry.frame.id);
      for (const child of entry?.childFrames || []) visit(child);
    };
    visit(frameTree);
    return ids;
  }
  function frameDescriptors(frameTree) {
    const frames = [];
    const visit = (entry) => {
      if (entry?.frame?.id) {
        frames.push({
          frameId: entry.frame.id,
          loaderId: entry.frame.loaderId || ""
        });
      }
      for (const child of entry?.childFrames || []) visit(child);
    };
    visit(frameTree);
    return frames;
  }
  function childFrameEntries(frameTree) {
    const entries = [];
    const visit = (entry) => {
      for (const child of entry?.childFrames || []) {
        if (child?.frame?.id) entries.push(child.frame);
        visit(child);
      }
    };
    visit(frameTree);
    return entries;
  }
  function isTransientChildFrameError(error) {
    const message = error instanceof Error ? error.message : String(error || "");
    return /(?:No frame for given id|Frame with the given id was not found|Cannot find context with specified id|Cannot find context)/i.test(message);
  }
  async function inspectEmbeddedExperiences(tabId) {
    const tree = await sendCdp(tabId, "Page.getFrameTree");
    const experiences = [];
    for (const frame of childFrameEntries(tree?.frameTree)) {
      try {
        const presentation = await readFrameOwnerPresentation(tabId, frame.id);
        const signals = await readFrameDocumentSignals(tabId, frame.id);
        experiences.push(classifyEmbeddedExperience({
          frameId: frame.id,
          url: signals.url || frame.url || "",
          name: presentation.name || frame.name || "",
          title: presentation.title || signals.title || "",
          width: presentation.width,
          height: presentation.height,
          visible: presentation.visible,
          textCharacters: signals.textCharacters,
          controls: signals.controls,
          images: signals.images,
          dialogs: signals.dialogs
        }));
      } catch (error) {
        if (!isTransientChildFrameError(error)) throw error;
      }
    }
    return experiences;
  }
  async function isolateInvisibleFrameOwners(tabId) {
    const tree = await sendCdp(tabId, "Page.getFrameTree");
    for (const frame of childFrameEntries(tree?.frameTree)) {
      let objectId = "";
      try {
        const owner = await sendCdp(tabId, "DOM.getFrameOwner", { frameId: frame.id });
        const resolved = await sendCdp(tabId, "DOM.resolveNode", {
          backendNodeId: owner.backendNodeId
        });
        objectId = resolved?.object?.objectId || "";
        if (!objectId) continue;
        await sendCdp(tabId, "Runtime.callFunctionOn", {
          objectId,
          functionDeclaration: isolateTechnicalFrameOwner.toString(),
          returnByValue: true
        });
      } catch (error) {
        if (!isTransientChildFrameError(error)) throw error;
      } finally {
        if (objectId) {
          await sendCdp(tabId, "Runtime.releaseObject", { objectId }, 5e3).catch(() => void 0);
        }
      }
    }
  }
  async function readFrameOwnerPresentation(tabId, frameId) {
    const owner = await sendCdp(tabId, "DOM.getFrameOwner", { frameId });
    const resolved = await sendCdp(tabId, "DOM.resolveNode", {
      backendNodeId: owner.backendNodeId
    });
    const objectId = resolved?.object?.objectId;
    if (!objectId) throw new Error("Chrome could not inspect an embedded frame.");
    try {
      const result = await sendCdp(tabId, "Runtime.callFunctionOn", {
        objectId,
        functionDeclaration: `function () {
        const rect = this.getBoundingClientRect();
        const style = getComputedStyle(this);
        const visible = rect.width > 0 && rect.height > 0 &&
          style.display !== "none" &&
          style.visibility !== "hidden" &&
          Number(style.opacity || 1) > 0 &&
          this.getAttribute("aria-hidden") !== "true";
        return {
          width: Math.round(rect.width),
          height: Math.round(rect.height),
          visible,
          name: this.getAttribute("name") || this.id || "",
          title: this.getAttribute("title") || this.getAttribute("aria-label") || ""
        };
      }`,
        returnByValue: true
      });
      return result?.result?.value || {
        width: 0,
        height: 0,
        visible: false,
        name: "",
        title: ""
      };
    } finally {
      await sendCdp(tabId, "Runtime.releaseObject", { objectId }, 5e3).catch(() => void 0);
    }
  }
  async function readFrameDocumentSignals(tabId, frameId) {
    const world = await sendCdp(tabId, "Page.createIsolatedWorld", {
      frameId,
      worldName: "souk-capture-embedded-experience",
      grantUniveralAccess: false
    });
    const contextId = world?.executionContextId;
    if (!Number.isInteger(contextId)) {
      throw new Error("The embedded Chrome context is unavailable.");
    }
    const result = await sendCdp(tabId, "Runtime.evaluate", {
      contextId,
      expression: `(() => ({
      url: location.href,
      title: document.title || "",
      textCharacters: (document.body?.innerText || "").trim().length,
      controls: document.querySelectorAll(
        'button,a[href],input,select,textarea,[role="button"],[role="link"]'
      ).length,
      images: document.images.length,
      dialogs: document.querySelectorAll('[role="dialog"],dialog,[aria-modal="true"]').length
    }))()`,
      returnByValue: true
    });
    if (result?.exceptionDetails) {
      throw new Error("Chrome could not inspect an embedded frame document.");
    }
    return result?.result?.value || {};
  }
  async function applyPrivacyToFrames(tabId, mode, coveredContexts = []) {
    const tree = await sendCdp(tabId, "Page.getFrameTree");
    const contexts = [];
    const mainFrameId = tree?.frameTree?.frame?.id || "";
    const covered = new Set(
      coveredContexts.map(({ frameId, loaderId }) => `${frameId}\0${loaderId}`)
    );
    try {
      for (const { frameId, loaderId } of frameDescriptors(tree?.frameTree)) {
        if (mode === "mask" && covered.has(`${frameId}\0${loaderId}`)) continue;
        try {
          const world = await sendCdp(tabId, "Page.createIsolatedWorld", {
            frameId,
            worldName: "souk-capture-privacy",
            grantUniveralAccess: false
          });
          const contextId = world?.executionContextId;
          if (!Number.isInteger(contextId)) throw new Error("The private Chrome context is unavailable.");
          const result = await sendCdp(tabId, "Runtime.evaluate", {
            contextId,
            expression: `(${applySnapshotPrivacy.toString()})(${JSON.stringify(mode)})`,
            returnByValue: true
          });
          contexts.push({ frameId, loaderId, contextId, isMainFrame: frameId === mainFrameId, result });
        } catch (error) {
          if (frameId !== mainFrameId && isTransientChildFrameError(error)) continue;
          throw error;
        }
      }
    } catch (error) {
      await restorePrivacyContexts(tabId, contexts).catch(() => void 0);
      throw error;
    }
    return contexts;
  }
  async function stabilizePrivacyCoverage(tabId, contexts) {
    for (let attempt = 0; attempt < 4; attempt += 1) {
      const missing = await missingPrivacyFrames(tabId, contexts);
      if (!missing.length) return;
      const additional = await applyPrivacyToFrames(tabId, "mask", contexts);
      if (additional.some((entry) => entry.result?.exceptionDetails || entry.result?.result?.value?.capped)) {
        throw new Error("The page contains too many private fields to capture safely.");
      }
      contexts.push(...additional);
    }
    await assertPrivacyCoverage(tabId, contexts);
  }
  async function captureProtectedSnapshots(tabId, privacyContexts) {
    for (let attempt = 0; attempt < 4; attempt += 1) {
      await stabilizePrivacyCoverage(tabId, privacyContexts);
      await sendCdp(tabId, "Page.setWebLifecycleState", { state: "frozen" });
      let protectedSnapshots = null;
      try {
        if ((await missingPrivacyFrames(tabId, privacyContexts)).length) continue;
        const renderSnapshot = await sendCdp(
          tabId,
          "DOMSnapshot.captureSnapshot",
          {
            computedStyles: [...COMPUTED_STYLE_PROPERTIES],
            includePaintOrder: true,
            includeDOMRects: true,
            includeBlendedBackgroundColors: true,
            includeTextColorOpacities: true
          }
        );
        assertSnapshotPrivacy(renderSnapshot);
        if (!snapshotFramesCovered(renderSnapshot, privacyContexts)) continue;
        const mhtmlSnapshot = await sendCdp(tabId, "Page.captureSnapshot", { format: "mhtml" });
        if ((await missingPrivacyFrames(tabId, privacyContexts)).length) continue;
        protectedSnapshots = { renderSnapshot, mhtmlSnapshot };
      } finally {
        await sendCdp(tabId, "Page.setWebLifecycleState", { state: "active" }).catch(() => void 0);
      }
      if (protectedSnapshots) return protectedSnapshots;
    }
    throw new Error(
      "Embedded content kept changing while Chrome created the private snapshot. Wait for the page to stabilize, then capture it again."
    );
  }
  async function assertPrivacyCoverage(tabId, contexts) {
    const missing = await missingPrivacyFrames(tabId, contexts);
    if (missing.length) {
      throw new Error(
        "Embedded content changed while private fields were masked. Wait for the page to stabilize, then capture it again."
      );
    }
  }
  async function missingPrivacyFrames(tabId, contexts) {
    const tree = await sendCdp(tabId, "Page.getFrameTree");
    const covered = new Set(
      contexts.map(({ frameId, loaderId }) => `${frameId}\0${loaderId}`)
    );
    return frameDescriptors(tree?.frameTree).filter(
      ({ frameId, loaderId }) => !covered.has(`${frameId}\0${loaderId}`)
    );
  }
  function snapshotFramesCovered(snapshot, contexts) {
    const coveredFrameIds = new Set(contexts.map(({ frameId }) => frameId));
    return !(snapshot?.documents || []).some(
      (document2) => {
        const frameId = Number.isInteger(document2?.frameId) ? String(snapshot?.strings?.[document2.frameId] || "") : String(document2?.frameId || "");
        return frameId && !coveredFrameIds.has(frameId);
      }
    );
  }
  async function restorePrivacyContexts(tabId, contexts) {
    const failures = [];
    for (const { contextId, isMainFrame } of contexts) {
      try {
        await sendCdp(tabId, "Runtime.evaluate", {
          contextId,
          expression: `(${applySnapshotPrivacy.toString()})("restore")`,
          returnByValue: true
        }, 5e3);
      } catch (error) {
        if (!isMainFrame && isTransientChildFrameError(error)) continue;
        failures.push(error);
      }
    }
    if (failures.length) {
      throw new Error("The page changed while private fields were restored. Reload it before continuing.");
    }
  }
  async function applyNodeIdentityToFrames(tabId, mode) {
    const tree = await sendCdp(tabId, "Page.getFrameTree");
    const contexts = [];
    try {
      const ids = frameIds(tree?.frameTree);
      const mainFrameId = tree?.frameTree?.frame?.id || "";
      for (let index = 0; index < ids.length; index += 1) {
        const frameId = ids[index];
        try {
          const world = await sendCdp(tabId, "Page.createIsolatedWorld", {
            frameId,
            worldName: "souk-capture-node-identity",
            grantUniveralAccess: false
          });
          const contextId = world?.executionContextId;
          if (!Number.isInteger(contextId)) throw new Error("The Chrome identity context is unavailable.");
          const result = await sendCdp(tabId, "Runtime.evaluate", {
            contextId,
            expression: `(${applyCaptureNodeIdentity.toString()})(${JSON.stringify(mode)}, ${JSON.stringify(`frame-${index}`)})`,
            returnByValue: true
          });
          contexts.push({ frameId, contextId, isMainFrame: frameId === mainFrameId, result });
        } catch (error) {
          if (frameId !== mainFrameId && isTransientChildFrameError(error)) continue;
          throw error;
        }
      }
    } catch (error) {
      await restoreNodeIdentityContexts(tabId, contexts).catch(() => void 0);
      throw error;
    }
    return contexts;
  }
  async function restoreNodeIdentityContexts(tabId, contexts) {
    const failures = [];
    for (const { contextId, isMainFrame } of contexts) {
      try {
        await sendCdp(tabId, "Runtime.evaluate", {
          contextId,
          expression: `(${applyCaptureNodeIdentity.toString()})("restore")`,
          returnByValue: true
        });
      } catch (error) {
        if (!isMainFrame && isTransientChildFrameError(error)) continue;
        failures.push(error);
      }
    }
    if (failures.length) throw failures[0];
  }
  async function recoverInterruptedCapture() {
    const stored = await chrome.storage.local.get(["captureRecovery"]);
    const tabId = Number(stored.captureRecovery?.tabId);
    if (!Number.isInteger(tabId) || tabId <= 0) return;
    let attached = false;
    let recovered = false;
    try {
      await chrome.debugger.attach({ tabId }, "1.3");
      attached = true;
      const contexts = await applyPrivacyToFrames(tabId, "restore");
      if (contexts.some((entry) => entry.result?.exceptionDetails)) {
        throw new Error("Chrome private-data restoration failed.");
      }
      const identityContexts = await applyNodeIdentityToFrames(tabId, "restore");
      if (identityContexts.some((entry) => entry.result?.exceptionDetails)) {
        throw new Error("Chrome capture-identity restoration failed.");
      }
      await sendCdp(tabId, "Runtime.evaluate", {
        expression: `(${applySnapshotFidelity.toString()})("restore")`,
        awaitPromise: true,
        returnByValue: true
      }, 5e3);
      recovered = true;
    } finally {
      if (attached) await chrome.debugger.detach({ tabId }).catch(() => void 0);
      if (recovered) await chrome.storage.local.remove(["captureRecovery"]);
    }
  }
})();
