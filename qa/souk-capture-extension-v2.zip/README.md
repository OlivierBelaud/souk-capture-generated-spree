# Souk Capture — Chrome extension POC

1. Ouvrir `chrome://extensions`.
2. Activer **Mode développeur**.
3. Cliquer **Charger l’extension non empaquetée**.
4. Sélectionner `apps/extension`.
5. Se connecter avec le même compte client que sur `/studio`.

Le manifeste autorise uniquement l’application `https://app.soukcapture.com`,
son URL Vercel initiale `https://souk-capture-frontend.vercel.app`, l’API
partagée `https://api.wearesouk.com` et les origines locales `localhost` /
`127.0.0.1`. Le Studio transmet sa session à l’extension après vérification de
l’origine ; aucune origine arbitraire ne peut injecter un token ou une URL d’API.

L’extension utilise `Page.captureSnapshot` pour produire un snapshot MHTML depuis
le vrai onglet Chrome de l’utilisateur, après connexion ou challenge anti-bot. Les
snapshots sont envoyés par fragments au backend MantaJS et ne contiennent jamais les
cookies du navigateur.
