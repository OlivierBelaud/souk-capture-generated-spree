import { DEFAULT_APP_ORIGIN, normalizeAppOrigin } from "./lib/product-config.mjs";

const app = document.querySelector("#app");
const storage = await chrome.storage.local.get([
  "accessToken",
  "appBaseUrl",
  "captureV2Project",
  "captureV2RunState",
]);

render();

function render() {
  const project = storage.captureV2Project;
  const run = storage.captureV2RunState;
  if (!storage.accessToken || !project) {
    app.innerHTML = `<section class="shell">
      ${brand()}
      <div class="card">
        <p class="eyebrow">Capture V2</p>
        <h2>Connect from Capture Studio</h2>
        <p class="muted">Sign in on the V2 application. It connects this extension securely, so you never enter your Souk password twice.</p>
        <button class="primary" id="open-studio">Open V2 Studio</button>
      </div>
    </section>`;
    document.querySelector("#open-studio")?.addEventListener("click", openStudio);
    return;
  }
  let sourceHost = "Storefront";
  try {
    sourceHost = new URL(project.sourceUrl).hostname;
  } catch {
    // Corrupt extension state is displayed safely and can be reset from Studio.
  }
  const observations = Array.isArray(run?.observations) ? run.observations : [];
  const warnings = Array.isArray(run?.warnings) ? run.warnings : [];
  const status = run?.status || "ready-to-start";
  app.innerHTML = `<section class="shell">
    ${brand()}
    <div class="card">
      <p class="eyebrow">Active V2 project</p>
      <h2>${escapeHtml(sourceHost)}</h2>
      <div class="url">${escapeHtml(project.sourceUrl)}</div>
      <div class="status ${status === "review_ready" ? "done" : status === "attention_required" ? "rejected" : "pending"}"><span class="dot"></span>${escapeHtml(status.replaceAll("_", " "))}</div>
    </div>
    <div class="card">
      <p class="eyebrow">Autonomous discovery <span class="count">${observations.length}</span></p>
      <h2>${status === "discovering" ? "Mapping the storefront…" : status === "review_ready" ? "Ready for review" : "Controlled from Studio"}</h2>
      <p class="muted">${status === "discovering" ? "You may keep browsing. Souk uses a dedicated tab and only follows safe same-origin GET routes." : "The Capture Studio owns the run; this popup is a live monitor."}</p>
      ${run?.currentUrl ? `<div class="url">${escapeHtml(run.currentUrl)}</div>` : ""}
      <ul class="inventory">${observations.slice(-6).reverse().map((item) => `<li><div><strong>${escapeHtml(item.title || item.kind)}</strong><small>${escapeHtml(item.kind)} · ${escapeHtml(item.state)}</small></div><small class="done">saved</small></li>`).join("") || "<li><small>No route captured in this run yet.</small></li>"}</ul>
      ${warnings.slice(-3).map((warning) => `<div class="notice">${escapeHtml(warning)}</div>`).join("")}
      <button class="secondary" id="open-project">View project in Capture V2</button>
    </div>
  </section>`;
  document.querySelector("#open-project")?.addEventListener("click", () => openStudio(project.projectId));
}

function brand() {
  return `<header class="brand"><div class="brand-mark"><img class="brand-logo" src="souk-capture-logo.svg" alt="Souk Capture" /></div><span class="status done"><span class="dot"></span>V2</span></header>`;
}

function openStudio(projectId = "") {
  let origin;
  try {
    origin = normalizeAppOrigin(storage.appBaseUrl || DEFAULT_APP_ORIGIN);
  } catch {
    origin = DEFAULT_APP_ORIGIN;
  }
  const url = new URL("/studio-v2", `${origin}/`);
  if (projectId) url.searchParams.set("project", projectId);
  chrome.tabs.create({ url: url.toString() });
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
